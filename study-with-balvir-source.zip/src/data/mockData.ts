import { ExamCategoryInfo, PassPlan, Question, MockTest, StudyNote, User } from '../types';

export const EXAM_CATEGORIES: ExamCategoryInfo[] = [
  {
    id: 'bpsc_tre',
    name: 'BPSC TRE (Teacher Recruitment)',
    hindiName: 'BPSC टी.आर.ई. (शिक्षक भर्ती परीक्षा)',
    badge: 'TRE 3.0 & 4.0',
    description: 'Specialized 5-option MCQs and full-length mocks for PRT (1-5), TGT (6-8, 9-10), and PGT (11-12) aspirants.',
    hindiDescription: 'प्राथमिक, माध्यमिक और उच्च माध्यमिक शिक्षक भर्ती परीक्षा हेतु 5-विकल्प वाले विशेष अभ्यास प्रश्न एवं मॉक टेस्ट।',
    totalQuestions: 1250,
    testCount: 45,
    subjects: ['Teaching Aptitude & CDP', 'General Studies (GS)', 'Bihar Special GK', 'Language (Hindi/English)', 'Mathematics & Science']
  },
  {
    id: 'ctet',
    name: 'CTET (Central Teacher Eligibility Test)',
    hindiName: 'CTET (केंद्रीय शिक्षक पात्रता परीक्षा)',
    badge: 'Paper 1 & Paper 2',
    description: 'Comprehensive preparation for CBSE CTET with NCERT-based CDP, Mathematics, EVS, and Pedagogy.',
    hindiDescription: 'CBSE केंद्रीय शिक्षक पात्रता परीक्षा के पेपर 1 एवं 2 हेतु बाल विकास एवं शिक्षण शास्त्र और विषयवार अभ्यास।',
    totalQuestions: 980,
    testCount: 38,
    subjects: ['Child Development & Pedagogy', 'Environmental Studies (EVS)', 'Mathematics & Pedagogy', 'Hindi Language', 'English Language']
  },
  {
    id: 'jtet',
    name: 'JTET (Jharkhand Teacher Eligibility Test)',
    hindiName: 'JTET (झारखंड शिक्षक पात्रता परीक्षा)',
    badge: 'Primary & Upper Primary',
    description: 'Tailored for JAC JTET with Jharkhand history, tribal culture, CDP, and regional language pedagogy.',
    hindiDescription: 'झारखंड एकेडमिक काउंसिल द्वारा आयोजित शिक्षक पात्रता परीक्षा हेतु झारखंड सामान्य ज्ञान एवं शिक्षण विधियां।',
    totalQuestions: 620,
    testCount: 24,
    subjects: ['Jharkhand Special GK & History', 'Child Psychology & Pedagogy', 'Language Pedagogy', 'Science & Mathematics', 'Social Studies']
  },
  {
    id: 'bpsc_cce',
    name: 'BPSC Civil Services (CCE)',
    hindiName: 'BPSC संयुक्त सिविल सेवा (CCE)',
    badge: '70th & 71st CCE',
    description: 'Standard 5-option pattern preparation for Bihar Civil Services Prelims with extensive Bihar GK and Current Affairs.',
    hindiDescription: 'बिहार लोक सेवा आयोग प्रारंभिक परीक्षा (70वीं एवं 71वीं) हेतु 5-विकल्प पैटर्न आधारित सम्पूर्ण तैयारी।',
    totalQuestions: 1540,
    testCount: 52,
    subjects: ['Bihar History & Culture', 'General Science', 'Indian Polity & Constitution', 'Geography of Bihar & India', 'Indian National Movement']
  }
];

export const INITIAL_QUESTIONS: Question[] = [
  // BPSC TRE Questions (5 options with standard E)
  {
    id: 'q_tre_01',
    examCategory: 'bpsc_tre',
    subject: 'Teaching Aptitude & CDP',
    questionEn: 'According to the National Education Policy (NEP) 2020, what is the new pedagogical and curricular structure replacing the 10+2 system?',
    questionHi: 'राष्ट्रीय शिक्षा नीति (NEP) 2020 के अनुसार, 10+2 प्रणाली के स्थान पर नई शैक्षणिक और पाठ्यचर्या संरचना क्या है?',
    optionsEn: [
      '5 + 3 + 3 + 4',
      '5 + 3 + 4 + 4',
      '3 + 5 + 3 + 4',
      '5 + 4 + 3 + 3',
      'More than one of the above / None of the above'
    ],
    optionsHi: [
      '5 + 3 + 3 + 4',
      '5 + 3 + 4 + 4',
      '3 + 5 + 3 + 4',
      '5 + 4 + 3 + 3',
      'उपर्युक्त में से एक से अधिक / उपर्युक्त में से कोई नहीं'
    ],
    correctOptionIndex: 0,
    explanationEn: 'NEP 2020 replaces the existing 10+2 model with a 5+3+3+4 formula: 5 years of Foundational Stage (ages 3-8), 3 years of Preparatory Stage (ages 8-11), 3 years of Middle Stage (ages 11-14), and 4 years of Secondary Stage (ages 14-18).',
    explanationHi: 'NEP 2020 ने पुरानी 10+2 प्रणाली को 5+3+3+4 संरचना में बदला है: 5 वर्ष बुनियादी स्तर (उम्र 3-8 वर्ष), 3 वर्ष प्रारंभिक/प्रारंभिक स्तर (8-11 वर्ष), 3 वर्ष मध्य स्तर (11-14 वर्ष), और 4 वर्ष माध्यमिक स्तर (14-18 वर्ष)।',
    difficulty: 'Easy',
    yearTag: 'BPSC TRE 2.0 (2023)',
    isBPSC5thOptionStandard: true
  },
  {
    id: 'q_tre_02',
    examCategory: 'bpsc_tre',
    subject: 'Bihar Special GK',
    questionEn: 'Who led the 1857 Revolt in Bihar against the British East India Company?',
    questionHi: '1857 के विद्रोह में बिहार से ब्रिटिश ईस्ट इंडिया कंपनी के विरुद्ध नेतृत्व किसने किया था?',
    optionsEn: [
      'Veer Kunwar Singh of Jagdishpur',
      'Peer Ali Khan of Patna',
      'Amar Singh',
      'Maulvi Ahmadullah',
      'More than one of the above / None of the above'
    ],
    optionsHi: [
      'जगदीशपुर के वीर कुंवर सिंह',
      'पटना के पीर अली खान',
      'अमर सिंह',
      'मौलवी अहमदुल्लाह',
      'उपर्युक्त में से एक से अधिक / उपर्युक्त में से कोई नहीं'
    ],
    correctOptionIndex: 4,
    explanationEn: 'In Bihar, the revolt was notably led by Veer Kunwar Singh (Jagdishpur/Bhojpur), Peer Ali Khan (Patna book seller who initiated rebellion in July 1857), and Amar Singh (brother of Kunwar Singh). Since multiple leaders played major roles, option E ("More than one of the above") is the exact BPSC official answer key pattern.',
    explanationHi: 'बिहार में 1857 की क्रांति का नेतृत्व वीर कुंवर सिंह ने जगदीशपुर से किया, पीर अली खान ने पटना से विद्रोह का शंखनाद किया, तथा अमर सिंह ने भी गुरिल्ला युद्ध लड़ा। अतः एक से अधिक सही होने के कारण विकल्प (E) सही उत्तर है।',
    difficulty: 'Hard',
    yearTag: 'BPSC TRE 1.0 (2023)',
    isBPSC5thOptionStandard: true
  },
  {
    id: 'q_tre_03',
    examCategory: 'bpsc_tre',
    subject: 'Teaching Aptitude & CDP',
    questionEn: 'In Jean Piaget\'s theory of cognitive development, the ability to mentally reverse actions and understand conservation emerges predominantly in which stage?',
    questionHi: 'जीन पियाजे के संज्ञानात्मक विकास के सिद्धांत में, क्रियाओं को मानसिक रूप से पलटने (प्रतिवर्तीता) और संरक्षण की समझ मुख्य रूप से किस अवस्था में विकसित होती है?',
    optionsEn: [
      'Sensorimotor Stage',
      'Pre-operational Stage',
      'Concrete Operational Stage',
      'Formal Operational Stage',
      'More than one of the above / None of the above'
    ],
    optionsHi: [
      'संवेदी-गामक अवस्था (0-2 वर्ष)',
      'पूर्व-संक्रियात्मक अवस्था (2-7 वर्ष)',
      'मूर्त संक्रियात्मक अवस्था (7-11 वर्ष)',
      'औपचारिक संक्रियात्मक अवस्था (11 वर्ष से ऊपर)',
      'उपर्युक्त में से एक से अधिक / उपर्युक्त में से कोई नहीं'
    ],
    correctOptionIndex: 2,
    explanationEn: 'Reversibility and conservation (capacity to realize that quantity remains constant despite changes in physical appearance) develop in the Concrete Operational Stage (roughly 7 to 11 years).',
    explanationHi: 'मूर्त संक्रियात्मक अवस्था (Concrete Operational Stage, 7 से 11 वर्ष) में बच्चे प्रतिवर्तीता (Reversibility) और संरक्षण (Conservation) की क्षमता प्राप्त कर लेते हैं।',
    difficulty: 'Moderate',
    yearTag: 'BPSC TRE 2.0 (2023)',
    isBPSC5thOptionStandard: true
  },
  {
    id: 'q_tre_04',
    examCategory: 'bpsc_tre',
    subject: 'General Studies (GS)',
    questionEn: 'Which Champaran Satyagraha event in 1917 prompted Mahatma Gandhi to visit Bihar?',
    questionHi: '1917 के चंपारण सत्याग्रह के सिलसिले में महात्मा गांधी को बिहार आने के लिए किसने आमंत्रित किया था?',
    optionsEn: [
      'Raj Kumar Shukla',
      'Dr. Rajendra Prasad',
      'Brajkishore Prasad',
      'Sachchidananda Sinha',
      'More than one of the above / None of the above'
    ],
    optionsHi: [
      'राजकुमार शुक्ल',
      'डॉ. राजेन्द्र प्रसाद',
      'ब्रजकिशोर प्रसाद',
      'सच्चिदानंद सिन्हा',
      'उपर्युक्त में से एक से अधिक / उपर्युक्त में से कोई नहीं'
    ],
    correctOptionIndex: 0,
    explanationEn: 'Raj Kumar Shukla, an indigo farmer from Champaran, met Mahatma Gandhi at the 1916 Lucknow session of the Indian National Congress and persistently persuaded him to visit Champaran to witness the plight of farmers under the Tinkathia system.',
    explanationHi: 'राजकुमार शुक्ल ने 1916 के कांग्रेस के लखनऊ अधिवेशन में गांधीजी से मुलाकात की और उन्हें चंपारण के नीलहे किसानों पर हो रहे तिनकठिया प्रथा के अत्याचारों को देखने और समाधान करने हेतु बिहार आने का आग्रह किया।',
    difficulty: 'Easy',
    yearTag: 'BPSC TRE 3.0 (2024)',
    isBPSC5thOptionStandard: true
  },
  {
    id: 'q_tre_05',
    examCategory: 'bpsc_tre',
    subject: 'Language (Hindi/English)',
    questionEn: 'Find the correct Sandhi-Vichchhed (संधि-विच्छेद) of the word "यद्यपि" (Yadyapi):',
    questionHi: 'शब्द "यद्यपि" का सही संधि-विच्छेद कौन-सा है?',
    optionsEn: [
      'यदि + अपि (Yadi + Api)',
      'यद् + यपि (Yad + Yapi)',
      'यद्य + अपि (Yadya + Api)',
      'या + द्यपि (Yaa + Dyapi)',
      'More than one of the above / None of the above'
    ],
    optionsHi: [
      'यदि + अपि',
      'यद् + यपि',
      'यद्य + अपि',
      'या + द्यपि',
      'उपर्युक्त में से एक से अधिक / उपर्युक्त में से कोई नहीं'
    ],
    correctOptionIndex: 0,
    explanationEn: '"यद्यपि" is formed by Yand-Swar Sandhi (यण् स्वर संधि): यदि + अपि = यद्यपि (इ + अ = य् + अ = य).',
    explanationHi: '"यद्यपि" का सही संधि-विच्छेद "यदि + अपि" है। यह यण् स्वर संधि का उदाहरण है, जहाँ इ/ई के बाद कोई भिन्न स्वर आने पर \'य्\' हो जाता है।',
    difficulty: 'Moderate',
    yearTag: 'BPSC TRE Qualifying Lang',
    isBPSC5thOptionStandard: true
  },

  // CTET Questions
  {
    id: 'q_ctet_01',
    examCategory: 'ctet',
    subject: 'Child Development & Pedagogy',
    questionEn: 'Lev Vygotsky proposed that child development is primarily shaped by:',
    questionHi: 'लेव वायगोत्स्की के अनुसार, बच्चों का संज्ञानात्मक विकास मुख्य रूप से किससे प्रभावित होता है?',
    optionsEn: [
      'Social interaction and cultural tools',
      'Genetic predispositions and biological maturation',
      'Operant conditioning and external reinforcements',
      'Individual assimilation and accommodation in isolation',
      'None of the above'
    ],
    optionsHi: [
      'सामाजिक अंतःक्रिया और सांस्कृतिक उपकरण',
      'आनुवंशिक प्रवृत्तियां और जैविक परिपक्वता',
      'क्रियाप्रसूत अनुकूलन और बाहरी पुनर्बलन',
      'अकेले में आत्मसातीकरण और समायोजन',
      'उपर्युक्त में से कोई नहीं'
    ],
    correctOptionIndex: 0,
    explanationEn: 'Lev Vygotsky\'s Sociocultural Theory emphasizes that cognitive growth occurs through social dialogue with more knowledgeable others (MKO) within the Zone of Proximal Development (ZPD).',
    explanationHi: 'वायगोत्स्की के सामाजिक-सांस्कृतिक सिद्धांत के अनुसार बालक समाज और संस्कृति के साथ अंतःक्रिया करके सीखता है, जिसमें भाषा और पाड़ (Scaffolding) महत्वपूर्ण भूमिका निभाते हैं।',
    difficulty: 'Easy',
    yearTag: 'CTET Jan 2024 Paper 1',
    isBPSC5thOptionStandard: false
  },
  {
    id: 'q_ctet_02',
    examCategory: 'ctet',
    subject: 'Environmental Studies (EVS)',
    questionEn: 'Which of the following is NOT one of the six broad themes identified in the NCERT EVS syllabus for primary classes (III-V)?',
    questionHi: 'निम्नलिखित में से कौन-सा प्राथमिक कक्षाओं (III-V) के NCERT EVS पाठ्यक्रम के छह मुख्य विषयों (Themes) में से एक नहीं है?',
    optionsEn: [
      'Family and Friends (परिवार एवं मित्र)',
      'Water and Shelter (जल एवं आवास)',
      'Things We Make and Do (चीजें जो हम बनाते और करते हैं)',
      'Atomic Energy and Electricity (परमाणु ऊर्जा और विद्युत)',
      'Travel and Food (यात्रा एवं भोजन)'
    ],
    optionsHi: [
      'परिवार एवं मित्र',
      'जल एवं आवास',
      'हम चीजें कैसे बनाते हैं',
      'परमाणु ऊर्जा और विद्युत',
      'यात्रा एवं भोजन'
    ],
    correctOptionIndex: 3,
    explanationEn: 'NCERT EVS syllabus is structured around six themes: 1. Family and Friends, 2. Food, 3. Shelter, 4. Water, 5. Travel, and 6. Things We Make and Do. "Atomic Energy" is not an EVS primary theme.',
    explanationHi: 'NCERT पर्यावरण अध्ययन (EVS) में 6 मुख्य थीम्स हैं: 1. परिवार और मित्र, 2. भोजन, 3. पानी, 4. आवास, 5. यात्रा, 6. चीजें जो हम बनाते हैं। \'परमाणु ऊर्जा\' प्राथमिक EVS का हिस्सा नहीं है।',
    difficulty: 'Easy',
    yearTag: 'CTET Aug 2023 Paper 1',
    isBPSC5thOptionStandard: false
  },
  {
    id: 'q_ctet_03',
    examCategory: 'ctet',
    subject: 'Child Development & Pedagogy',
    questionEn: 'A teacher discovers that a student repeatedly writes "b" as "d" and "saw" as "was". Which learning disability is most likely indicated?',
    questionHi: 'एक शिक्षक पाता है कि एक विद्यार्थी बार-बार "b" को "d" और "saw" को "was" लिखता व पढ़ता है। यह किस अधिगम अक्षमता (Learning Disability) का संकेत हो सकता है?',
    optionsEn: [
      'Dyscalculia (गणना विकार)',
      'Dyslexia (पठन विकार)',
      'Dysgraphia (लेखन विकार)',
      'ADHD (अवधान न्यूनता विकार)',
      'Dysphasia (भाषा विकार)'
    ],
    optionsHi: [
      'डिस्कैलकुलिया (गणना संबंधी विकार)',
      'डिस्लेक्सिया (पठन विकार)',
      'डिस्ग्राफिया (लेखन संबंधी विकार)',
      'ADHD (अतिसक्रियता विकार)',
      'डिस्फेजिया (वाक् विकार)'
    ],
    correctOptionIndex: 1,
    explanationEn: 'Dyslexia is a specific learning disorder characterized by difficulties with word recognition, reading comprehension, and letter reversal (e.g. b/d, was/saw).',
    explanationHi: 'डिस्लेक्सिया (Dyslexia) एक पठन विकार है जिसमें वर्णों को पहचानने, शब्दों को उल्टा पढ़ने (जैसे b को d या saw को was) में कठिनाई होती है।',
    difficulty: 'Moderate',
    yearTag: 'CTET 2024 Paper 2',
    isBPSC5thOptionStandard: false
  },

  // JTET Questions
  {
    id: 'q_jtet_01',
    examCategory: 'jtet',
    subject: 'Jharkhand Special GK & History',
    questionEn: 'The historic "Ulgulan" (Great Tumult) rebellion in Jharkhand was led by which revered freedom fighter?',
    questionHi: 'झारखंड में ऐतिहासिक "उलगुलान" (महान विद्रोह) का नेतृत्व किस श्रद्धेय स्वतंत्रता सेनानी ने किया था?',
    optionsEn: [
      'Birsa Munda',
      'Sidho and Kanho Murmu',
      'Tilka Manjhi',
      'Jatra Bhagat',
      'Nilambar and Pitambar'
    ],
    optionsHi: [
      'भगवान बिरसा मुंडा',
      'सिदो एवं कान्हू मुर्मू',
      'तिलका मांझी',
      'जतरा भगत',
      'नीलांबर और पीतांबर'
    ],
    correctOptionIndex: 0,
    explanationEn: 'The Ulgulan (1899–1900) was led by Bhagwan Birsa Munda in the Chotanagpur plateau against British land policies, feudal landlords, and exploitation of tribal rights.',
    explanationHi: '1899-1900 में छोटानागपुर क्षेत्र में भगवान बिरसा मुंडा के नेतृत्व में हुए मुंडा विद्रोह को "उलगुलान" (विशाल हलचल/विद्रोह) कहा जाता है।',
    difficulty: 'Easy',
    yearTag: 'JTET Previous Year',
    isBPSC5thOptionStandard: false
  },
  {
    id: 'q_jtet_02',
    examCategory: 'jtet',
    subject: 'Jharkhand Special GK & History',
    questionEn: 'Which national park in Jharkhand is famous as one of the earliest tiger reserves under Project Tiger (1973)?',
    questionHi: 'झारखंड का कौन-सा राष्ट्रीय उद्यान 1973 में प्रोजेक्ट टाइगर के तहत स्थापित शुरुआती बाघ अभयारण्यों में से एक के रूप में प्रसिद्ध है?',
    optionsEn: [
      'Betla National Park (Latehar)',
      'Dalma Wildlife Sanctuary (Jamshedpur)',
      'Hazaribagh Wildlife Sanctuary',
      'Palamu Wildlife Reserve only',
      'Topchanchi Sanctuary'
    ],
    optionsHi: [
      'बेतला राष्ट्रीय उद्यान (लातेहार)',
      'दलमा वन्यजीव अभयारण्य (जमशेदपुर)',
      'हजारीबाग वन्यजीव अभयारण्य',
      'केवल पलामू वन्यजीव अभयारण्य',
      'तोपचांची अभयारण्य'
    ],
    correctOptionIndex: 0,
    explanationEn: 'Betla National Park, located in Latehar and Palamu districts of Jharkhand, was among the first national parks in India to be declared a Tiger Reserve under Project Tiger.',
    explanationHi: 'बेतला राष्ट्रीय उद्यान (लातेहार/पलामू) भारत के प्रथम 9 टाइगर रिजर्वों में से एक था, जहाँ 1932 में विश्व की पहली बाघ गणना भी की गई थी।',
    difficulty: 'Moderate',
    yearTag: 'JTET Special',
    isBPSC5thOptionStandard: false
  },

  // BPSC Civil Services (CCE) Questions
  {
    id: 'q_cce_01',
    examCategory: 'bpsc_cce',
    subject: 'Bihar History & Culture',
    questionEn: 'Which ancient university was founded by the Pala dynasty ruler Gopala I / Dharmapala in modern Bihar?',
    questionHi: 'पाल वंश के शासक धर्मपाल द्वारा आधुनिक बिहार में किस प्राचीन विश्वविद्यालय की स्थापना की गई थी?',
    optionsEn: [
      'Vikramashila University',
      'Nalanda University',
      'Odantapuri University',
      'Somapura Mahavihara',
      'More than one of the above / None of the above'
    ],
    optionsHi: [
      'विक्रमशिला विश्वविद्यालय',
      'नालंदा विश्वविद्यालय',
      'ओदंतपुरी विश्वविद्यालय',
      'सोमपुरा महाविहार',
      'उपर्युक्त में से एक से अधिक / उपर्युक्त में से कोई नहीं'
    ],
    correctOptionIndex: 0,
    explanationEn: 'Vikramashila University (located in Kahalgaon, modern Bhagalpur district, Bihar) was founded by King Dharmapala of the Pala dynasty in the late 8th or early 9th century. Nalanda was founded by Kumargupta I of Gupta dynasty.',
    explanationHi: 'विक्रमशिला विश्वविद्यालय की स्थापना 8वीं-9वीं शताब्दी में पाल राजा धर्मपाल ने की थी, जो वर्तमान में भागलपुर जिले के अंतीचक (कहलगांव) में स्थित है। नालंदा की स्थापना गुप्त शासक कुमारगुप्त प्रथम ने की थी।',
    difficulty: 'Moderate',
    yearTag: '68th BPSC CCE Prelims',
    isBPSC5thOptionStandard: true
  },
  {
    id: 'q_cce_02',
    examCategory: 'bpsc_cce',
    subject: 'Geography of Bihar & India',
    questionEn: 'Through which of the following districts does the river Ganga enter the state of Bihar?',
    questionHi: 'गंगा नदी निम्नलिखित में से किस जिले से बिहार राज्य में प्रवेश करती है?',
    optionsEn: [
      'Buxar (बक्सर)',
      'Bhojpur (भोजपुर)',
      'Saran (सारण)',
      'Patna (पटना)',
      'More than one of the above / None of the above'
    ],
    optionsHi: [
      'बक्सर (चौसा)',
      'भोजपुर',
      'सारण',
      'पटना',
      'उपर्युक्त में से एक से अधिक / उपर्युक्त में से कोई नहीं'
    ],
    correctOptionIndex: 0,
    explanationEn: 'River Ganga enters Bihar at Chausa in Buxar district after flowing through Uttar Pradesh. It divides the state into North Bihar and South Bihar planes and exits through Katihar/Bhagalpur.',
    explanationHi: 'गंगा नदी उत्तर प्रदेश से प्रवाहित होते हुए बिहार के बक्सर जिले के चौसा के समीप प्रवेश करती है और लगभग 445 किमी दूरी बिहार में तय करती है।',
    difficulty: 'Easy',
    yearTag: '69th BPSC CCE Prelims',
    isBPSC5thOptionStandard: true
  },
  {
    id: 'q_cce_03',
    examCategory: 'bpsc_cce',
    subject: 'Indian Polity & Constitution',
    questionEn: 'Under which Article of the Constitution of India is the Advocate General for the State appointed by the Governor?',
    questionHi: 'भारत के संविधान के किस अनुच्छेद के तहत राज्यपाल द्वारा राज्य के महाधिवक्ता (Advocate General) की नियुक्ति की जाती है?',
    optionsEn: [
      'Article 165',
      'Article 177',
      'Article 164',
      'Article 76',
      'More than one of the above / None of the above'
    ],
    optionsHi: [
      'अनुच्छेद 165',
      'अनुच्छेद 177',
      'अनुच्छेद 164',
      'अनुच्छेद 76',
      'उपर्युक्त में से एक से अधिक / उपर्युक्त में से कोई नहीं'
    ],
    correctOptionIndex: 0,
    explanationEn: 'Article 165 deals with the Advocate General for the State appointed by the Governor. Article 76 deals with the Attorney General of India appointed by the President.',
    explanationHi: 'संविधान के अनुच्छेद 165 के तहत राज्य के महाधिवक्ता की नियुक्ति राज्यपाल द्वारा की जाती है। अनुच्छेद 76 भारत के महान्यायवादी से संबंधित है।',
    difficulty: 'Moderate',
    yearTag: '67th BPSC Re-exam',
    isBPSC5thOptionStandard: true
  }
];

export const INITIAL_MOCK_TESTS: MockTest[] = [
  {
    id: 'test_tre_free_01',
    title: 'BPSC TRE 3.0 / 4.0 Teaching Aptitude & GS Mini Mock',
    hindiTitle: 'BPSC टी.आर.ई. 3.0 / 4.0 शिक्षण अभिरुचि एवं सामान्य अध्ययन मिनी मॉक',
    examCategory: 'bpsc_tre',
    isPremium: false,
    durationMinutes: 15,
    totalMarks: 50,
    passMarks: 20,
    negativeMarking: 0,
    questionIds: ['q_tre_01', 'q_tre_02', 'q_tre_03', 'q_tre_04', 'q_tre_05'],
    attemptsCount: 14280,
    difficulty: 'Exam Level',
    descriptionEn: 'Official pattern 5-option mock test covering NEP 2020, Bihar Special History, Piaget Pedagogy, Champaran Satyagraha, and Hindi Grammar.',
    descriptionHi: 'आधिकारिक 5-विकल्प पैटर्न पर आधारित मॉक टेस्ट जिसमें नई शिक्षा नीति, बिहार का इतिहास, बाल मनोविज्ञान, और हिंदी व्याकरण समाहित हैं।'
  },
  {
    id: 'test_ctet_free_01',
    title: 'CTET CDP & Pedagogy Foundation Test (Paper 1 & 2)',
    hindiTitle: 'CTET बाल विकास एवं शिक्षण शास्त्र आधार टेस्ट (पेपर 1 और 2)',
    examCategory: 'ctet',
    isPremium: false,
    durationMinutes: 15,
    totalMarks: 30,
    passMarks: 18,
    negativeMarking: 0,
    questionIds: ['q_ctet_01', 'q_ctet_02', 'q_ctet_03', 'q_tre_01', 'q_tre_03'],
    attemptsCount: 22450,
    difficulty: 'Moderate',
    descriptionEn: 'Core concepts of Piaget, Vygotsky, inclusive education, NCERT EVS themes, and learning disabilities for CTET aspirants.',
    descriptionHi: 'पियाजे, वायगोत्स्की, समावेशी शिक्षा और शिक्षण विधियों पर आधारित केंद्रीय शिक्षक पात्रता परीक्षा स्पेशल टेस्ट।'
  },
  {
    id: 'test_tre_prem_01',
    title: 'BPSC TRE 4.0 All-India Ranker Full Length Mock #1',
    hindiTitle: 'BPSC टी.आर.ई. 4.0 ऑल इंडिया रेंकर फुल लेंथ मॉक #1',
    examCategory: 'bpsc_tre',
    isPremium: true,
    priceInr: 199,
    durationMinutes: 120,
    totalMarks: 120,
    passMarks: 48,
    negativeMarking: 0,
    questionIds: ['q_tre_01', 'q_tre_02', 'q_tre_03', 'q_tre_04', 'q_tre_05', 'q_cce_01', 'q_cce_02'],
    attemptsCount: 8930,
    difficulty: 'Exam Level',
    descriptionEn: 'Complete 120-marks simulation with exact 5 options, Section 1 (Language qualifying), Section 2 (GS & Bihar GK), and Section 3 (Subject Pedagogy).',
    descriptionHi: 'सम्पूर्ण 120 अंकों का फुल लेंथ मॉक टेस्ट, वास्तविक परीक्षा पैटर्न और 5 विकल्पों के साथ सम्पूर्ण व्याख्या।'
  },
  {
    id: 'test_jtet_free_01',
    title: 'JTET Jharkhand GK & Child Psychology Primer',
    hindiTitle: 'JTET झारखंड सामान्य ज्ञान एवं बाल मनोविज्ञान प्राइमर',
    examCategory: 'jtet',
    isPremium: false,
    durationMinutes: 15,
    totalMarks: 30,
    passMarks: 15,
    negativeMarking: 0,
    questionIds: ['q_jtet_01', 'q_jtet_02', 'q_ctet_01', 'q_ctet_03', 'q_tre_01'],
    attemptsCount: 7120,
    difficulty: 'Moderate',
    descriptionEn: 'Jharkhand tribal history, Birsa Munda movement, Betla Tiger Reserve, and modern child pedagogy.',
    descriptionHi: 'झारखंड के जनजातीय आंदोलन, भगवान बिरसा मुंडा, बेतला नेशनल पार्क और बाल मनोविज्ञान पर आधारित टेस्ट।'
  },
  {
    id: 'test_cce_prem_01',
    title: '70th BPSC CCE Prelims Target GS Mock Series #1',
    hindiTitle: '70वीं BPSC प्रारंभिक परीक्षा टारगेट GS मॉक टेस्ट #1',
    examCategory: 'bpsc_cce',
    isPremium: true,
    priceInr: 249,
    durationMinutes: 120,
    totalMarks: 150,
    passMarks: 95,
    negativeMarking: 0.33,
    questionIds: ['q_cce_01', 'q_cce_02', 'q_cce_03', 'q_tre_02', 'q_tre_04'],
    attemptsCount: 11400,
    difficulty: 'Exam Level',
    descriptionEn: 'Rigorous 5-option BPSC Civil Services Prelims mock with 1/3rd negative marking, deep Bihar geography, polity, and modern history.',
    descriptionHi: '1/3 निगेटिव मार्किंग और 5-विकल्प पैटर्न सहित 70वीं BPSC प्रारंभिक परीक्षा हेतु उच्च स्तरीय मॉक टेस्ट।'
  }
];

export const INITIAL_STUDY_NOTES: StudyNote[] = [
  {
    id: 'note_01',
    examCategory: 'bpsc_tre',
    subject: 'Teaching Aptitude & CDP',
    titleEn: 'National Education Policy (NEP) 2020: 5+3+3+4 Structure & Key Provisions',
    titleHi: 'राष्ट्रीय शिक्षा नीति (NEP) 2020: 5+3+3+4 संरचना एवं प्रमुख प्रावधान',
    readTimeMinutes: 7,
    isFree: true,
    publishedDate: '12 Oct 2026',
    author: 'Balvir Sir',
    keyPointsEn: [
      'Foundational Stage (5 yrs): 3 yrs Anganwadi/Pre-school + 2 yrs Primary (Grades 1-2), age 3-8, play-based learning.',
      'Preparatory Stage (3 yrs): Grades 3-5, age 8-11, discovery and experiential learning.',
      'Middle Stage (3 yrs): Grades 6-8, age 11-14, experiential learning in sciences, maths, humanities.',
      'Secondary Stage (4 yrs): Grades 9-12, age 14-18, multidisciplinary study, critical thinking, flexibility.',
      'Target: 100% Gross Enrolment Ratio (GER) in school education by 2030.'
    ],
    keyPointsHi: [
      'बुनियादी स्तर (5 वर्ष): 3 वर्ष आंगनवाड़ी/प्री-स्कूल + 2 वर्ष प्राथमिक (कक्षा 1-2), आयु 3-8 वर्ष, खेल आधारित अधिगम।',
      'प्रारंभिक स्तर (3 वर्ष): कक्षा 3-5, आयु 8-11 वर्ष, गतिविधि एवं खोज आधारित शिक्षा।',
      'मध्य स्तर (3 वर्ष): कक्षा 6-8, आयु 11-14 वर्ष, विज्ञान, गणित और सामाजिक विज्ञान का प्रयोगात्मक अध्ययन।',
      'माध्यमिक स्तर (4 वर्ष): कक्षा 9-12, आयु 14-18 वर्ष, बहु-विषयक अध्ययन एवं आलोचनात्मक चिंतन।',
      'लक्ष्य: वर्ष 2030 तक स्कूली शिक्षा में 100% सकल नामांकन अनुपात (GER) हासिल करना।'
    ],
    contentEn: `The National Education Policy (NEP) 2020 marks the first education policy of the 21st century in India, replacing the thirty-four-year-old NPE 1986.

1. Universal Access & Foundational Literacy:
Special emphasis is laid on Foundational Literacy and Numeracy (FLN) through the NIPUN Bharat Mission. All students must attain reading with comprehension and basic mathematical operations by Grade 3.

2. Mother Tongue & Multilingualism:
Where possible, the medium of instruction until at least Grade 5 (preferably Grade 8) will be the home language, mother tongue, or local language.

3. Assessment Reforms (PARAKH):
A national assessment centre named PARAKH (Performance Assessment, Review, and Analysis of Knowledge for Holistic Development) is set up to guide standard-setting.

4. Teacher Recruitment & Continuous Professional Development (CPD):
Teachers must undergo at least 50 hours of CPD every year for continuous pedagogical upskilling.`,
    contentHi: `राष्ट्रीय शिक्षा नीति (NEP) 2020 भारत की 21वीं सदी की पहली शिक्षा नीति है, जिसने 34 वर्ष पुरानी 1986 की नीति का स्थान लिया है।

1. बुनियादी साक्षरता और संख्या ज्ञान (FLN):
निपुण भारत (NIPUN Bharat) मिशन के माध्यम से कक्षा 3 तक सभी बच्चों के लिए बुनियादी साक्षरता एवं संख्यात्मक ज्ञान अनिवार्य बनाया गया है।

2. मातृभाषा और बहुभाषावाद:
कम से कम कक्षा 5 (और अधिमानतः कक्षा 8) तक शिक्षा का माध्यम मातृभाषा/स्थानीय भाषा में रखने पर विशेष बल दिया गया है।

3. मूल्यांकन सुधार (परख - PARAKH):
छात्रों के समग्र विकास के मूल्यांकन हेतु राष्ट्रीय मूल्यांकन केंद्र 'परख' की स्थापना की गई है।

4. शिक्षक भर्ती और सतत व्यावसायिक विकास (CPD):
शिक्षकों के लिए प्रतिवर्ष कम से कम 50 घंटे का सतत व्यावसायिक प्रशिक्षण (CPD) अनिवार्य किया गया है।`
  },
  {
    id: 'note_02',
    examCategory: 'bpsc_tre',
    subject: 'Bihar Special GK',
    titleEn: '1857 Revolt in Bihar: Veer Kunwar Singh, Jagdishpur & Peer Ali',
    titleHi: 'बिहार में 1857 की क्रांति: वीर कुंवर सिंह, जगदीशपुर एवं पीर अली की भूमिका',
    readTimeMinutes: 9,
    isFree: true,
    publishedDate: '18 Oct 2026',
    author: 'Balvir Sir',
    keyPointsEn: [
      'Veer Kunwar Singh of Jagdishpur (Bhojpur) led the revolt at the ripe age of nearly 80.',
      '3rd July 1857: Peer Ali, a bookseller in Patna, initiated the rebellion; British Deputy Opium Agent Dr. Lyell was killed.',
      '25th July 1857: Three regiments at Danapur (Dinapore) cantonment mutinied and marched to Shahabad to join Kunwar Singh.',
      'Kunwar Singh liberated Arrah, fought battles in Rewa, Banda, and Azamgarh, and re-entered Jagdishpur victorious on 23rd April 1858.',
      'Bihar celebrates 23rd April as "Vijayotsav Divas" (Victory Day) in his memory.'
    ],
    keyPointsHi: [
      'जगदीशपुर (भोजपुर) के जमींदार वीर कुंवर सिंह ने लगभग 80 वर्ष की उम्र में अंग्रेजों के विरुद्ध वीरतापूर्ण नेतृत्व किया।',
      '3 जुलाई 1857: पटना के पुस्तक विक्रेता पीर अली ने विद्रोह का बिगुल फूंका जिसमें अंग्रेज अधिकारी डॉ. लॉयल मारा गया।',
      '25 जुलाई 1857: दानापुर छावनी के 7वें, 8वें और 40वें रेजिमेंट के सैनिकों ने विद्रोह कर कुंवर सिंह का नेतृत्व स्वीकार किया।',
      'कुंवर सिंह ने आजमगढ़, रीवा और मिर्जापुर में अंग्रेजों को पराजित किया और 23 अप्रैल 1858 को जगदीशपुर पर पुनः विजय प्राप्त की।',
      'बिहार सरकार प्रतिवर्ष 23 अप्रैल को "विजयोत्सव दिवस" के रूप में मनाती है।'
    ],
    contentEn: `The 1857 rebellion in Bihar is one of the most prominent topics in BPSC TRE and CCE exams.

1. Outbreak in Deoghar (Rohini):
The first spark of 1857 in Bihar (now Jharkhand) occurred on 12 June 1857 at Rohini village in Deoghar, where soldiers of the 5th Irregular Cavalry rebelled.

2. Patna Uprising under Peer Ali:
On 3 July 1857, Peer Ali Khan led an armed demonstration in Patna. William Tayler, the Commissioner of Patna, ruthlessly executed Peer Ali and many associates.

3. Kunwar Singh's Military Campaigns:
Kunwar Singh was a master of guerrilla warfare. After defeating Captain Dunbar near Arrah, he joined forces with Nana Saheb at Kanpur and captured Azamgarh. Even after losing his left arm to a cannonball wound at the Ganga crossing, he defeated Le Grand's British forces at Jagdishpur.`,
    contentHi: `बिहार में 1857 की क्रांति BPSC TRE और सिविल सेवा परीक्षाओं का अत्यंत महत्वपूर्ण अध्याय है।

1. रोहिणी (देवघर) में प्रथम विद्रोह:
बिहार (तत्कालीन) में 1857 की पहली चिंगारी 12 जून 1857 को देवघर जिले के रोहिणी गांव में 5वीं अनियमित घुड़सवार सेना के सैनिकों द्वारा जलाई गई।

2. पटना में पीर अली का संघर्ष:
3 जुलाई 1857 को पटना सिटी में पीर अली खान ने विद्रोह का नेतृत्व किया। पटना के तत्कालीन कमिश्नर विलियम टेलर ने पीर अली को फांसी की सजा दी।

3. वीर कुंवर सिंह का सैन्य पराक्रम:
कुंवर सिंह छापामार युद्ध (Guerrilla Warfare) के अद्वितीय योद्धा थे। उन्होंने आरा के पास कैप्टन डनबर को परास्त किया, नाना साहेब के साथ मिलकर कानपुर व आजमगढ़ में ब्रिटिश सेना को धूल चटाई। गंगा पार करते समय हाथ में गोली लगने पर उन्होंने अपना बायां हाथ काटकर गंगा मैया को समर्पित कर दिया था।`
  },
  {
    id: 'note_03',
    examCategory: 'ctet',
    subject: 'Child Development & Pedagogy',
    titleEn: 'Cognitive Theories: Jean Piaget vs Lev Vygotsky Comparative Chart',
    titleHi: 'संज्ञानात्मक विकास: जीन पियाजे बनाम लेव वायगोत्स्की तुलनात्मक सारणी',
    readTimeMinutes: 8,
    isFree: true,
    publishedDate: '15 Oct 2026',
    author: 'Balvir Sir',
    keyPointsEn: [
      'Piaget is a Cognitive Constructivist; Vygotsky is a Social Constructivist.',
      'Piaget says "Development precedes learning"; Vygotsky asserts "Learning precedes development".',
      'Piaget view on Language: Egocentric speech with minimal cognitive utility; thoughts develop before language.',
      'Vygotsky view on Language: Critical tool for thought; Private Speech guides self-regulation.',
      'ZPD (Zone of Proximal Development) and Scaffolding are core pillars of Vygotsky\'s educational application.'
    ],
    keyPointsHi: [
      'पियाजे संज्ञानात्मक रचनावादी (Cognitive Constructivist) हैं; जबकि वायगोत्स्की सामाजिक रचनावादी (Social Constructivist) हैं।',
      'पियाजे का मानना है कि "विकास पहले होता है, अधिगम बाद में"; वायगोत्स्की के अनुसार "अधिगम विकास को दिशा देता है"।',
      'भाषा पर विचार: पियाजे ने बच्चों की बातचीत को "अहंकेंद्रित वाक्" माना; वायगोत्स्की ने इसे "निजी वाक् (Private Speech)" कहा जो स्व-नियमन में सहायक है।',
      'ZPD (समीपस्थ विकास का क्षेत्र) एवं पाड़ (Scaffolding): वायगोत्स्की के सिद्धांत के प्रमुख आधार स्तंभ हैं।'
    ],
    contentEn: `Both Jean Piaget and Lev Vygotsky agree that children are active builders of their knowledge ("little scientists"), but their viewpoints diverge on social context and language.

1. Stages vs Continuity:
Piaget proposed 4 universal biological stages: Sensorimotor (0-2), Preoperational (2-7), Concrete Operational (7-11), and Formal Operational (11+). Vygotsky rejected strict age stages, stating cognitive development is culturally continuous.

2. The Role of Scaffolding & MKO:
Vygotsky introduced the 'More Knowledgeable Other' (MKO) who provides temporary structural support (Scaffolding) to help the learner bridge the gap between actual ability and potential ability (ZPD).`,
    contentHi: `पियाजे और वायगोत्स्की दोनों स्वीकार करते हैं कि बच्चे ज्ञान के सक्रिय निर्माता हैं, किन्तु उनके सीखने की प्रक्रिया में बुनियादी अंतर हैं।

1. अवस्थाएं बनाम निरंतरता:
पियाजे ने 4 निश्चित अवस्थाएं दीं:
1. संवेदी-गामक (0-2 वर्ष)
2. पूर्व-संक्रियात्मक (2-7 वर्ष)
3. मूर्त-संक्रियात्मक (7-11 वर्ष)
4. औपचारिक संक्रियात्मक (11 वर्ष से ऊपर)
वायगोत्स्की ने किसी निश्चित अवस्था का खंडन किया और विकास को निरंतर सामाजिक प्रक्रिया बताया।

2. पाड़/ढांचा (Scaffolding) एवं MKO:
वायगोत्स्की के अनुसार जब कोई अधिक ज्ञानी व्यक्ति (MKO - शिक्षक, अभिभावक, सहपाठी) बालक को सीखने में अस्थायी सहायता देता है, तो उसे Scaffolding कहते हैं।`
  },
  {
    id: 'note_04',
    examCategory: 'jtet',
    subject: 'Jharkhand Special GK & History',
    titleEn: 'Birsa Munda & The Ulgulan Movement (1899-1900)',
    titleHi: 'भगवान बिरसा मुंडा एवं उलगुलान विद्रोह (1899-1900)',
    readTimeMinutes: 6,
    isFree: true,
    publishedDate: '20 Oct 2026',
    author: 'Balvir Sir',
    keyPointsEn: [
      'Born on 15 November 1875 in Ulihatu village (Khunti district).',
      'Celebrated as "Janjatiya Gaurav Divas" across India on 15th November.',
      'Protested against the erosion of the Khuntkatti (traditional joint land tenure) system by Dikus (outsiders) and the British.',
      'Outcome: Led to the historic Chotanagpur Tenancy Act (CNT Act) of 1908, protecting tribal land rights.'
    ],
    keyPointsHi: [
      'जन्म 15 नवंबर 1875 को उलिहातू गांव (खूंटी जिला) में हुआ था।',
      'भारत सरकार 15 नवंबर को "जनजातीय गौरव दिवस" के रूप में मनाती है।',
      'अंग्रेजों और दिकुओं द्वारा मुंडाओं की पारंपरिक "खूंटकट्टी प्रथा" समाप्त करने के विरोध में विद्रोह हुआ।',
      'विद्रोह का ऐतिहासिक परिणाम: 1908 का छोटानागपुर काश्तकारी अधिनियम (CNT Act) पारित हुआ जिसने आदिवासी जमीनों की रक्षा की।'
    ],
    contentEn: `The Ulgulan led by Birsa Munda is central to Jharkhand Teacher Eligibility Test (JTET). Birsa Munda proclaimed himself a prophet of Singbonga (Supreme God) and founded the Birsait faith, preaching monotheism, social purity, and freedom from British exploitation.`,
    contentHi: `भगवान बिरसा मुंडा का उलगुलान आंदोलन JTET परीक्षा का अनिवार्य विषय है। उन्होंने मुंडा समाज में मद्यपान और अंधविश्वासों का विरोध किया तथा सिंहबोंगा की आराधना का उपदेश दिया।`
  }
];

export const PASS_PLANS: PassPlan[] = [
  {
    id: 'plan_tre_pass',
    title: 'BPSC TRE Super Pass',
    hindiTitle: 'BPSC टी.आर.ई. सुपर पास',
    priceInr: 199,
    originalPriceInr: 499,
    validity: '6 Months (Till TRE 4.0 Exam)',
    targetExamBadge: 'BPSC TRE Special',
    popular: true,
    features: [
      '45+ Full Length & Sectional 5-Option Mock Tests',
      'Detailed bilingual solutions with rank & percentile analytics',
      'PRT, TGT, PGT special pedagogy & GS notes',
      'Unlimited re-attempts with speed and accuracy breakdown',
      'BPSC standard Option E ("More than one / None") practice bank'
    ],
    hindiFeatures: [
      '45+ फुल लेंथ और विषयवार 5-विकल्प वाले मॉक टेस्ट',
      'रैंक और परसेंटाइल के साथ विस्तृत द्विभाषी व्याख्या',
      'प्राथमिक, माध्यमिक और उच्च माध्यमिक स्पेशल नोट्स',
      'असीमित री-अटेम्प्ट और समय विश्लेषण',
      'BPSC मानक विकल्प E ("उपर्युक्त में से एक से अधिक / कोई नहीं") प्रश्न बैंक'
    ]
  },
  {
    id: 'plan_all_teaching',
    title: 'All-Teaching Exams Super Combo',
    hindiTitle: 'ऑल टीचिंग एग्जाम महा पैक (कॉम्बो)',
    priceInr: 299,
    originalPriceInr: 899,
    validity: '12 Months (All Teaching Exams)',
    targetExamBadge: 'BPSC TRE + CTET + JTET',
    popular: false,
    features: [
      'Access to ALL tests: BPSC TRE, CTET Paper 1 & 2, and JTET',
      '110+ Full-length tests with live simulated exam interface',
      'Complete bilingual PDF study notes and formula sheets',
      'State-wise rank prediction among 50,000+ aspirants',
      'Direct priority doubt resolution community'
    ],
    hindiFeatures: [
      'सभी परीक्षाओं का एक्सेस: BPSC TRE, CTET पेपर 1 व 2, और JTET',
      '110+ फुल लेंथ टेस्ट असली परीक्षा हॉल जैसे इंटरफेस के साथ',
      'सम्पूर्ण द्विभाषी PDF नोट्स और फॉर्मूला शीट्स',
      '50,000+ अभ्यर्थियों के बीच राज्य स्तरीय रैंक प्रेडिक्टर',
      'डायरेक्ट डाउट रेजोल्यूशन कम्युनिटी एक्सेस'
    ]
  },
  {
    id: 'plan_bpsc_cce',
    title: 'BPSC 70th & 71st CCE Prelims Pass',
    hindiTitle: '70वीं एवं 71वीं BPSC प्रीलिम्स पास',
    priceInr: 249,
    originalPriceInr: 599,
    validity: '8 Months',
    targetExamBadge: 'BPSC Civil Services',
    popular: false,
    features: [
      '50+ High-yield General Studies tests on standard 5-option format',
      'In-depth Bihar Special History, Geography & Budget 2026',
      'Negative marking simulation (-0.33 per incorrect)',
      'Previous 10 years solved papers with updated facts'
    ],
    hindiFeatures: [
      '50+ उच्च स्तरीय 5-विकल्प वाले सामान्य अध्ययन मॉक टेस्ट',
      'बिहार विशेष इतिहास, भूगोल, आर्थिक सर्वेक्षण 2026',
      '1/3 निगेटिव मार्किंग सिमुलेशन और कट-ऑफ विश्लेषण',
      'पिछले 10 वर्षों के हल प्रश्न पत्र'
    ]
  }
];

export const DEMO_USER: User = {
  id: 'usr_student_01',
  name: 'Aman Kumar Verma',
  email: 'aman.verma@student.in',
  phone: '+91 98765 43210',
  role: 'student',
  targetExam: 'bpsc_tre',
  hasPremiumPass: false,
  bookmarks: ['q_tre_02', 'q_ctet_01', 'q_cce_01'],
  savedNotes: ['note_01', 'note_02'],
  testHistory: [
    {
      id: 'att_01',
      testId: 'test_tre_free_01',
      testTitle: 'BPSC TRE 3.0 / 4.0 Teaching Aptitude & GS Mini Mock',
      examCategory: 'bpsc_tre',
      date: '2026-10-22',
      score: 40,
      totalMarks: 50,
      totalQuestions: 5,
      correctCount: 4,
      incorrectCount: 1,
      unattemptedCount: 0,
      timeTakenSeconds: 380,
      accuracyPercentage: 80,
      percentile: 94.2,
      rank: 420,
      totalParticipants: 14280,
      userAnswers: {
        'q_tre_01': 0,
        'q_tre_02': 0, // incorrect (correct was 4)
        'q_tre_03': 2,
        'q_tre_04': 0,
        'q_tre_05': 0
      },
      markedForReview: ['q_tre_02']
    }
  ]
};

export const DEMO_ADMIN: User = {
  id: 'usr_admin_01',
  name: 'Balvir Singh (Director)',
  email: 'balvirjee@gmail.com',
  phone: '+91 98000 12345',
  role: 'admin',
  targetExam: 'bpsc_tre',
  hasPremiumPass: true,
  passPlanName: 'Admin Master Pass',
  bookmarks: [],
  savedNotes: [],
  testHistory: []
};
