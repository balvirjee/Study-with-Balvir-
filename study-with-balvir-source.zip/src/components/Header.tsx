import React, { useState } from 'react';
import {
  GraduationCap,
  Languages,
  Server,
  User as UserIcon,
  Crown,
  LogOut,
  Shield,
  Layers,
  ChevronDown,
  Download
} from 'lucide-react';
import { useApp, AppView } from '../context/AppContext';
import { EXAM_CATEGORIES } from '../data/mockData';
import { ExamCategory } from '../types';

export const Header: React.FC = () => {
  const {
    currentUser,
    currentView,
    setCurrentView,
    targetExam,
    setTargetExam,
    appLanguage,
    setAppLanguage,
    setIsAuthModalOpen,
    setIsArchitectureModalOpen,
    setIsExportModalOpen,
    logout
  } = useApp();

  const [isExamDropdownOpen, setIsExamDropdownOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  const selectedCategoryInfo = EXAM_CATEGORIES.find((c) => c.id === targetExam) || EXAM_CATEGORIES[0];

  const navLinks: { view: AppView; label: string; hindiLabel: string }[] = [
    { view: 'home', label: 'Home', hindiLabel: 'होम' },
    { view: 'mock_tests', label: 'Mock Tests', hindiLabel: 'मॉक टेस्ट' },
    { view: 'practice', label: '5-Option MCQs', hindiLabel: '5-विकल्प अभ्यास' },
    { view: 'notes', label: 'Study Notes', hindiLabel: 'अध्ययन नोट्स' },
    { view: 'dashboard', label: 'My Dashboard', hindiLabel: 'डैशबोर्ड' },
    { view: 'pricing', label: 'Pass & Plans', hindiLabel: 'पास एवं प्लान' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between gap-6 h-16">
          {/* Zone 1: Brand title, single line */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setCurrentView('home')}
              className="flex items-center gap-2.5 text-left focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-700 text-white flex items-center justify-center shadow-xs">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div className="whitespace-nowrap">
                <span className="text-base sm:text-lg font-extrabold tracking-tight text-blue-950 block leading-tight">
                  Study with Balvir
                </span>
                <span className="text-[11px] font-medium text-blue-600 block leading-tight">
                  BPSC TRE · CTET · JTET · CCE
                </span>
              </div>
            </button>

            {/* Target Exam Switcher Dropdown */}
            <div className="relative hidden md:block">
              <button
                onClick={() => setIsExamDropdownOpen(!isExamDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
              >
                <span>{selectedCategoryInfo.badge}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              </button>

              {isExamDropdownOpen && (
                <div className="absolute left-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 py-1 z-50">
                  <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Select Target Exam
                  </div>
                  {EXAM_CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setTargetExam(cat.id);
                        setIsExamDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 text-xs transition-colors flex items-center justify-between ${
                        targetExam === cat.id ? 'bg-blue-50 text-blue-700 font-semibold' : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <span className="truncate">{appLanguage === 'hi' ? cat.hindiName : cat.name}</span>
                      <span className="text-[10px] text-slate-400 ml-2 shrink-0">{cat.badge}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Zone 2: Navigation Links, single-line text links */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold text-slate-600">
            {navLinks.map((link) => (
              <button
                key={link.view}
                onClick={() => setCurrentView(link.view)}
                className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
                  currentView === link.view
                    ? 'text-blue-700 font-bold border-b-2 border-blue-700'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {appLanguage === 'hi' ? link.hindiLabel : link.label}
              </button>
            ))}
            {currentUser?.role === 'admin' && (
              <button
                onClick={() => setCurrentView('admin')}
                className={`whitespace-nowrap shrink-0 py-1 transition-colors flex items-center gap-1 ${
                  currentView === 'admin'
                    ? 'text-amber-700 font-bold border-b-2 border-amber-600'
                    : 'text-slate-700 hover:text-slate-900'
                }`}
              >
                <Shield className="w-3.5 h-3.5 text-amber-600" />
                <span>Admin Panel</span>
              </button>
            )}
          </nav>

          {/* Zone 3: Actions (Source ZIP Download, Language switch, Architecture blueprint badge, User profile) */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {/* Download Source Code ZIP */}
            <button
              onClick={() => setIsExportModalOpen(true)}
              className="flex items-center gap-1 px-2 py-1.5 sm:px-2.5 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors shadow-xs"
              title="Download complete project source code (ZIP)"
            >
              <Download className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <span className="text-[11px] sm:text-xs">Export ZIP</span>
            </button>

            {/* Architecture Blueprint Button */}
            <button
              onClick={() => setIsArchitectureModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              title="View production database and payment integration blueprint"
            >
              <Server className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden sm:inline">Backend Arch</span>
            </button>

            {/* Language Toggle */}
            <button
              onClick={() => setAppLanguage(appLanguage === 'hi' ? 'en' : 'hi')}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors border border-blue-200"
              title="Toggle Hindi / English"
            >
              <Languages className="w-3.5 h-3.5 text-blue-700" />
              <span>{appLanguage === 'hi' ? 'English' : 'हिंदी'}</span>
            </button>

            {/* User / Auth */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                  className="flex items-center gap-2 pl-2 pr-2.5 py-1.5 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
                >
                  <div className="w-6 h-6 rounded-full bg-blue-700 text-white flex items-center justify-center text-[11px] font-bold">
                    {currentUser.name.charAt(0)}
                  </div>
                  <span className="hidden md:inline max-w-[100px] truncate">{currentUser.name}</span>
                  {currentUser.hasPremiumPass && (
                    <Crown className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                  )}
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {isProfileMenuOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50">
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-900 truncate">{currentUser.name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                      <span className="inline-block mt-1 text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                        {currentUser.role === 'admin' ? 'Educator Admin' : 'Active Student'}
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        setCurrentView('dashboard');
                        setIsProfileMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <UserIcon className="w-3.5 h-3.5 text-slate-500" />
                      <span>My Dashboard & Bookmarks</span>
                    </button>

                    <button
                      onClick={() => {
                        setCurrentView('pricing');
                        setIsProfileMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Crown className="w-3.5 h-3.5 text-amber-500" />
                      <span>Pass & Premium Access</span>
                    </button>

                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => {
                          setCurrentView('admin');
                          setIsProfileMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-amber-800 hover:bg-amber-50 flex items-center gap-2"
                      >
                        <Shield className="w-3.5 h-3.5 text-amber-600" />
                        <span>Admin Console</span>
                      </button>
                    )}

                    <div className="border-t border-slate-100 my-1" />

                    <button
                      onClick={() => {
                        logout();
                        setIsProfileMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                    >
                      <LogOut className="w-3.5 h-3.5 text-rose-600" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs whitespace-nowrap shrink-0"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
