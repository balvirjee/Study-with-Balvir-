import React, { useState } from 'react';
import {
  User as UserIcon,
  Crown,
  Bookmark,
  Clock,
  Award,
  CheckCircle2,
  TrendingUp,
  RotateCcw,
  BookOpen,
  ArrowRight,
  Trash2,
  HelpCircle,
  Calendar,
  AlertCircle,
  Download
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EXAM_CATEGORIES } from '../data/mockData';
import { ExamCategory, Question } from '../types';

export const DashboardView: React.FC = () => {
  const {
    currentUser,
    setCurrentView,
    targetExam,
    setTargetExam,
    startMockTest,
    viewTestResult,
    questions,
    studyNotes,
    toggleBookmark,
    toggleSavedNote,
    appLanguage,
    setIsAuthModalOpen,
    setIsExportModalOpen
  } = useApp();

  const [activeTab, setActiveTab] = useState<'history' | 'bookmarks' | 'notes'>('history');

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto my-12 p-8 bg-white border border-slate-200 rounded-3xl text-center space-y-4 shadow-xs">
        <UserIcon className="w-12 h-12 text-slate-400 mx-auto" />
        <h2 className="text-lg font-bold text-slate-900">Sign in to Access Your Student Dashboard</h2>
        <p className="text-xs text-slate-500 leading-relaxed">
          Track your mock test scores, maintain revision bookmarks, review bilingual explanations, and predict your BPSC ranking.
        </p>
        <button
          onClick={() => setIsAuthModalOpen(true)}
          className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs"
        >
          Sign In / Register Account
        </button>
      </div>
    );
  }

  // Calculate statistics
  const testHistory = currentUser.testHistory || [];
  const totalTestsAttempted = testHistory.length;
  const avgAccuracy = totalTestsAttempted > 0
    ? Math.round(testHistory.reduce((acc, t) => acc + t.accuracyPercentage, 0) / totalTestsAttempted)
    : 0;
  const highestScore = totalTestsAttempted > 0
    ? Math.max(...testHistory.map((t) => t.score))
    : 0;

  // Bookmarked questions
  const bookmarkedQuestions = questions.filter((q) => currentUser.bookmarks.includes(q.id));

  // Saved notes
  const savedNotesList = studyNotes.filter((n) => currentUser.savedNotes.includes(n.id));

  const targetCategory = EXAM_CATEGORIES.find((c) => c.id === currentUser.targetExam) || EXAM_CATEGORIES[0];

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-16">
      {/* Student Profile & Pass Strip */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-700 to-indigo-600 text-white flex items-center justify-center text-xl font-bold shadow-xs shrink-0">
            {currentUser.name.charAt(0)}
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-slate-900">{currentUser.name}</h1>
              {currentUser.hasPremiumPass ? (
                <span className="flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-100 border border-amber-200 px-2 py-0.5 rounded-full">
                  <Crown className="w-3 h-3 text-amber-600 fill-amber-600" />
                  <span>PREMIUM PASS</span>
                </span>
              ) : (
                <span className="text-[10px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">
                  Free Student Plan
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500">
              {currentUser.email} · {currentUser.phone}
            </p>
            <div className="flex items-center gap-2 pt-1 text-xs">
              <span className="text-slate-500">Targeting:</span>
              <select
                value={currentUser.targetExam}
                onChange={(e) => setTargetExam(e.target.value as ExamCategory)}
                className="bg-blue-50 text-blue-900 font-semibold px-2 py-0.5 rounded border border-blue-200 text-xs focus:outline-none"
              >
                {EXAM_CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.badge}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Upgrade / Pass Action & Source Export */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0 w-full md:w-auto">
          <button
            onClick={() => setIsExportModalOpen(true)}
            className="px-3.5 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-emerald-700" />
            <span>Download Source ZIP</span>
          </button>

          {!currentUser.hasPremiumPass ? (
            <button
              onClick={() => setCurrentView('pricing')}
              className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2"
            >
              <Crown className="w-4 h-4 fill-slate-950" />
              <span>Unlock Premium Pass (₹199)</span>
            </button>
          ) : (
            <div className="text-right text-xs px-2">
              <span className="text-slate-400 block text-[11px]">Pass Validity</span>
              <span className="font-semibold text-emerald-700">Active until Oct 2027</span>
            </div>
          )}
        </div>
      </div>

      {/* 4 Performance Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Tests Attempted
          </span>
          <div className="text-2xl font-extrabold text-slate-900 tabular-nums">
            {totalTestsAttempted}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Full & Sectional Mocks</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Avg. Accuracy
          </span>
          <div className="text-2xl font-extrabold text-blue-700 tabular-nums">
            {avgAccuracy}%
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Across all submissions</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Bookmarks
          </span>
          <div className="text-2xl font-extrabold text-amber-600 tabular-nums">
            {bookmarkedQuestions.length}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Saved tricky 5-option MCQs</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Study Streak
          </span>
          <div className="text-2xl font-extrabold text-emerald-600 tabular-nums">
            7 Days 🔥
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Consistent revision</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveTab('history')}
          className={`py-3 px-6 text-xs font-bold border-b-2 transition-colors ${
            activeTab === 'history'
              ? 'border-blue-600 text-blue-700 bg-white'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Test Attempt History ({testHistory.length})
        </button>
        <button
          onClick={() => setActiveTab('bookmarks')}
          className={`py-3 px-6 text-xs font-bold border-b-2 transition-colors ${
            activeTab === 'bookmarks'
              ? 'border-blue-600 text-blue-700 bg-white'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Bookmarked Questions ({bookmarkedQuestions.length})
        </button>
        <button
          onClick={() => setActiveTab('notes')}
          className={`py-3 px-6 text-xs font-bold border-b-2 transition-colors ${
            activeTab === 'notes'
              ? 'border-blue-600 text-blue-700 bg-white'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Saved Study Notes ({savedNotesList.length})
        </button>
      </div>

      {/* Tab: Test History */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          {testHistory.length === 0 ? (
            <div className="p-12 text-center bg-white border border-slate-200 rounded-2xl space-y-3">
              <Award className="w-10 h-10 text-slate-400 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">No Tests Attempted Yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Take your first free BPSC TRE or CTET mock test to establish your baseline score and estimated rank.
              </p>
              <button
                onClick={() => setCurrentView('mock_tests')}
                className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
              >
                Browse Mock Tests
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {testHistory.map((item) => (
                <div
                  key={item.id}
                  className="p-5 bg-white border border-slate-200 rounded-2xl shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-slate-300 transition-colors"
                >
                  <div className="space-y-1 max-w-xl">
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>{item.date}</span>
                      </span>
                      <span>·</span>
                      <span className="font-semibold text-blue-700 uppercase">{item.examCategory.replace('_', ' ')}</span>
                    </div>
                    <h3 className="text-sm sm:text-base font-bold text-slate-900">
                      {item.testTitle}
                    </h3>
                    <div className="flex flex-wrap items-center gap-3 pt-1 text-xs text-slate-600">
                      <span>
                        Score: <strong className="text-slate-900 tabular-nums">{item.score}/{item.totalMarks}</strong>
                      </span>
                      <span>·</span>
                      <span>
                        Accuracy: <strong className="text-slate-900 tabular-nums">{item.accuracyPercentage}%</strong>
                      </span>
                      <span>·</span>
                      <span>
                        Rank: <strong className="text-emerald-700 tabular-nums">#{item.rank}</strong>
                      </span>
                      <span>·</span>
                      <span>
                        Percentile: <strong className="text-blue-700 tabular-nums">{item.percentile}%</strong>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
                    <button
                      onClick={() => viewTestResult(item)}
                      className="flex-1 sm:flex-initial px-4 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
                    >
                      View Analysis & Solutions
                    </button>
                    <button
                      onClick={() => startMockTest(item.testId)}
                      className="px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                      title="Retake this test"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab: Bookmarks */}
      {activeTab === 'bookmarks' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-500">
              Review and revise questions you marked as difficult or high-yield
            </p>
            {bookmarkedQuestions.length > 0 && (
              <button
                onClick={() => setCurrentView('practice')}
                className="text-xs font-bold text-blue-700 hover:text-blue-800 flex items-center gap-1"
              >
                <span>Practice Bookmarks in Quiz Arena</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {bookmarkedQuestions.length === 0 ? (
            <div className="p-12 text-center bg-white border border-slate-200 rounded-2xl space-y-3">
              <Bookmark className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">No Bookmarked Questions</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                While practicing 5-option MCQs or reviewing test solutions, click the bookmark icon to save questions here for rapid last-minute revision.
              </p>
              <button
                onClick={() => setCurrentView('practice')}
                className="px-4 py-2 text-xs font-semibold text-blue-600 bg-blue-50 rounded-lg"
              >
                Go to 5-Option Practice
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {bookmarkedQuestions.map((q, idx) => (
                <div key={q.id} className="p-5 bg-white border border-slate-200 rounded-2xl shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                        #{idx + 1}
                      </span>
                      <span className="text-xs font-medium text-slate-500">{q.subject}</span>
                    </div>
                    <button
                      onClick={() => toggleBookmark(q.id)}
                      className="p-1.5 text-amber-600 hover:text-slate-400 transition-colors"
                      title="Remove bookmark"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <p className="text-sm font-semibold text-slate-900 leading-relaxed">
                    {appLanguage === 'hi' ? q.questionHi : q.questionEn}
                  </p>

                  <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200 text-xs text-slate-800 space-y-1">
                    <span className="font-bold text-slate-900 block">
                      Correct Answer: Option ({['A', 'B', 'C', 'D', 'E'][q.correctOptionIndex]})
                    </span>
                    <p className="leading-relaxed">
                      {appLanguage === 'hi' ? q.explanationHi : q.explanationEn}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab: Saved Study Notes */}
      {activeTab === 'notes' && (
        <div className="space-y-4">
          {savedNotesList.length === 0 ? (
            <div className="p-12 text-center bg-white border border-slate-200 rounded-2xl space-y-3">
              <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">No Saved Notes</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Explore the free bilingual study notes section and save chapters to your student library for offline revision.
              </p>
              <button
                onClick={() => setCurrentView('notes')}
                className="px-4 py-2 text-xs font-semibold text-blue-600 bg-blue-50 rounded-lg"
              >
                Browse Study Notes
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {savedNotesList.map((note) => (
                <div key={note.id} className="p-5 bg-white border border-slate-200 rounded-2xl shadow-xs space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                      {note.subject}
                    </span>
                    <button
                      onClick={() => toggleSavedNote(note.id)}
                      className="text-slate-400 hover:text-rose-600 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900">
                    {appLanguage === 'hi' ? note.titleHi : note.titleEn}
                  </h4>
                  <p className="text-xs text-slate-500 line-clamp-2">
                    {appLanguage === 'hi' ? note.contentHi : note.contentEn}
                  </p>
                  <div className="pt-2">
                    <button
                      onClick={() => setCurrentView('notes')}
                      className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
                    >
                      <span>Open Note in Reader</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
