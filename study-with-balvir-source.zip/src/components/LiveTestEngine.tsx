import React, { useState, useEffect } from 'react';
import {
  Clock,
  Languages,
  AlertTriangle,
  Bookmark,
  Check,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  Send,
  HelpCircle,
  RotateCcw
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Question, TestAttemptResult } from '../types';

export const LiveTestEngine: React.FC = () => {
  const {
    activeTest,
    exitActiveTest,
    completeMockTest,
    questions,
    currentUser,
    appLanguage,
    showToast
  } = useApp();

  if (!activeTest) return null;

  // Resolve questions for this test
  const testQuestions: Question[] = activeTest.questionIds
    .map((qid) => questions.find((q) => q.id === qid))
    .filter((q): q is Question => q !== undefined);

  // States
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, number | null>>({});
  const [markedForReview, setMarkedForReview] = useState<string[]>([]);
  const [visitedQuestions, setVisitedQuestions] = useState<string[]>([testQuestions[0]?.id || '']);
  const [remainingSeconds, setRemainingSeconds] = useState<number>(activeTest.durationMinutes * 60);
  const [testLang, setTestLang] = useState<'hi' | 'en'>(appLanguage);
  const [isPaletteOpenMobile, setIsPaletteOpenMobile] = useState<boolean>(false);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState<boolean>(false);

  // Timer countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setRemainingSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitTest(true); // Auto submit on timer expiry
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const currentQ = testQuestions[currentIdx];

  // Track visited questions
  const markAsVisited = (qid: string) => {
    if (!visitedQuestions.includes(qid)) {
      setVisitedQuestions((prev) => [...prev, qid]);
    }
  };

  const handleSelectOption = (optionIndex: number) => {
    if (!currentQ) return;
    setUserAnswers((prev) => ({
      ...prev,
      [currentQ.id]: optionIndex
    }));
  };

  const handleClearResponse = () => {
    if (!currentQ) return;
    setUserAnswers((prev) => ({
      ...prev,
      [currentQ.id]: null
    }));
    setMarkedForReview((prev) => prev.filter((id) => id !== currentQ.id));
  };

  const handleMarkForReviewAndNext = () => {
    if (!currentQ) return;
    if (!markedForReview.includes(currentQ.id)) {
      setMarkedForReview((prev) => [...prev, currentQ.id]);
    }
    advanceNext();
  };

  const handleSaveAndNext = () => {
    advanceNext();
  };

  const advanceNext = () => {
    if (currentIdx < testQuestions.length - 1) {
      const nextIdx = currentIdx + 1;
      setCurrentIdx(nextIdx);
      markAsVisited(testQuestions[nextIdx].id);
    }
  };

  const advancePrev = () => {
    if (currentIdx > 0) {
      const prevIdx = currentIdx - 1;
      setCurrentIdx(prevIdx);
      markAsVisited(testQuestions[prevIdx].id);
    }
  };

  const jumpToQuestion = (idx: number) => {
    setCurrentIdx(idx);
    markAsVisited(testQuestions[idx].id);
    setIsPaletteOpenMobile(false);
  };

  // Question status classifier for palette
  const getQuestionStatus = (qid: string) => {
    const isAnswered = userAnswers[qid] !== undefined && userAnswers[qid] !== null;
    const isMarked = markedForReview.includes(qid);
    const isVisited = visitedQuestions.includes(qid);

    if (isMarked && isAnswered) return 'answered_and_marked';
    if (isMarked) return 'marked';
    if (isAnswered) return 'answered';
    if (isVisited) return 'not_answered';
    return 'not_visited';
  };

  // Tallies for palette & submit modal
  const answeredCount = Object.values(userAnswers).filter((v) => v !== null && v !== undefined).length;
  const markedCount = markedForReview.length;
  const notAnsweredCount = testQuestions.filter((q) => {
    const ans = userAnswers[q.id];
    return visitedQuestions.includes(q.id) && (ans === null || ans === undefined);
  }).length;
  const notVisitedCount = testQuestions.filter((q) => !visitedQuestions.includes(q.id)).length;

  const handleSubmitTest = (isAutoSubmit = false) => {
    let correctCount = 0;
    let incorrectCount = 0;
    let unattemptedCount = 0;

    testQuestions.forEach((q) => {
      const userChoice = userAnswers[q.id];
      if (userChoice === undefined || userChoice === null) {
        unattemptedCount++;
      } else if (userChoice === q.correctOptionIndex) {
        correctCount++;
      } else {
        incorrectCount++;
      }
    });

    const marksPerCorrect = activeTest.totalMarks / (testQuestions.length || 1);
    const negativeDeduction = activeTest.negativeMarking * marksPerCorrect;
    const rawScore = (correctCount * marksPerCorrect) - (incorrectCount * negativeDeduction);
    const finalScore = Math.max(0, Math.round(rawScore * 10) / 10);

    const accuracy = correctCount + incorrectCount > 0
      ? Math.round((correctCount / (correctCount + incorrectCount)) * 100)
      : 0;

    const timeSpent = (activeTest.durationMinutes * 60) - remainingSeconds;

    // Simulated rank and percentile among participants
    const totalParts = activeTest.attemptsCount + 1;
    const percentile = Math.min(99.4, Math.max(25.0, Math.round((finalScore / (activeTest.totalMarks || 1)) * 95 + 4)));
    const rank = Math.max(1, Math.round(totalParts * (1 - (percentile / 100))));

    const result: TestAttemptResult = {
      id: 'att_' + Date.now(),
      testId: activeTest.id,
      testTitle: activeTest.title,
      examCategory: activeTest.examCategory,
      date: new Date().toISOString().split('T')[0],
      score: finalScore,
      totalMarks: activeTest.totalMarks,
      totalQuestions: testQuestions.length,
      correctCount,
      incorrectCount,
      unattemptedCount,
      timeTakenSeconds: timeSpent,
      accuracyPercentage: accuracy,
      percentile,
      rank,
      totalParticipants: totalParts,
      userAnswers,
      markedForReview
    };

    completeMockTest(result);
  };

  // Format countdown mm:ss
  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const isLowTime = remainingSeconds < 180;
  const optionLetters = ['A', 'B', 'C', 'D', 'E'];

  return (
    <div className="fixed inset-0 z-50 bg-slate-100 flex flex-col overflow-hidden">
      {/* Top Test Header (TCS iON / Testbook style) */}
      <header className="bg-slate-900 text-white h-14 sm:h-16 px-4 sm:px-6 flex items-center justify-between shrink-0 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="text-left">
            <h1 className="text-xs sm:text-sm font-bold truncate max-w-[200px] sm:max-w-md">
              {activeTest.title}
            </h1>
            <span className="text-[10px] text-blue-300 hidden sm:inline">
              Candidate: {currentUser?.name || 'Aman Kumar Verma'}
            </span>
          </div>
        </div>

        {/* Center: Live Countdown Timer */}
        <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border font-mono font-bold text-xs sm:text-sm tabular-nums ${
          isLowTime
            ? 'bg-rose-950 text-rose-300 border-rose-700 animate-pulse'
            : 'bg-slate-800 text-amber-300 border-slate-700'
        }`}>
          <Clock className="w-4 h-4 text-amber-400" />
          <span>{formatTimer(remainingSeconds)}</span>
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          {/* Question language switch */}
          <button
            onClick={() => setTestLang(testLang === 'hi' ? 'en' : 'hi')}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 text-slate-200 transition-colors"
          >
            <Languages className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">{testLang === 'hi' ? 'हिंदी' : 'English'}</span>
          </button>

          {/* Palette toggle on mobile */}
          <button
            onClick={() => setIsPaletteOpenMobile(!isPaletteOpenMobile)}
            className="lg:hidden p-2 text-slate-300 hover:text-white bg-slate-800 rounded-lg border border-slate-700"
            title="Question Palette"
          >
            <Menu className="w-4 h-4" />
          </button>

          {/* Submit Test Button */}
          <button
            onClick={() => setIsSubmitModalOpen(true)}
            className="px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Send className="w-3 h-3" />
            <span>Submit</span>
          </button>
        </div>
      </header>

      {/* Main Workspace: Question Area (left) + Question Palette (right) */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Active Question Container */}
        <div className="flex-1 flex flex-col bg-white overflow-y-auto">
          {/* Question Sub-Header */}
          <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-blue-900 bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-md">
                Question {currentIdx + 1}
              </span>
              <span className="text-xs font-medium text-slate-600 truncate max-w-xs">
                Section: {currentQ?.subject}
              </span>
            </div>

            <div className="flex items-center gap-3 text-xs text-slate-500 font-medium">
              <span className="text-emerald-700">Marks: +{activeTest.totalMarks / (testQuestions.length || 1)}</span>
              {activeTest.negativeMarking > 0 && (
                <span className="text-rose-600">Neg: -{activeTest.negativeMarking}</span>
              )}
            </div>
          </div>

          {/* Question Content */}
          {currentQ && (
            <div className="flex-1 p-6 sm:p-8 space-y-6 max-w-4xl">
              {/* Question Text */}
              <div className="space-y-2">
                <p className="text-base sm:text-lg font-bold text-slate-900 leading-relaxed">
                  {testLang === 'hi' ? currentQ.questionHi : currentQ.questionEn}
                </p>
                {/* Secondary subtitle in other language for convenience */}
                <p className="text-xs text-slate-500 italic">
                  {testLang === 'hi' ? currentQ.questionEn : currentQ.questionHi}
                </p>
              </div>

              {/* 5 Options (A, B, C, D, E) */}
              <div className="space-y-3 pt-2">
                {(testLang === 'hi' ? currentQ.optionsHi : currentQ.optionsEn).map((optText, optIdx) => {
                  const isSelected = userAnswers[currentQ.id] === optIdx;
                  const letter = optionLetters[optIdx];

                  return (
                    <div
                      key={optIdx}
                      onClick={() => handleSelectOption(optIdx)}
                      className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center gap-3 ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/70 shadow-xs ring-1 ring-blue-600'
                          : 'border-slate-200 bg-white hover:border-blue-300'
                      }`}
                    >
                      <div
                        className={`w-7 h-7 rounded-lg border flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                          isSelected
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-slate-50 text-slate-700 border-slate-300'
                        }`}
                      >
                        {letter}
                      </div>
                      <span className="text-xs sm:text-sm text-slate-800 leading-snug">
                        {optText}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Bottom Action Bar */}
          <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <button
                onClick={handleClearResponse}
                disabled={userAnswers[currentQ?.id] === null || userAnswers[currentQ?.id] === undefined}
                className="px-3 py-2 text-xs font-semibold text-slate-600 bg-white hover:bg-slate-100 rounded-lg border border-slate-300 transition-colors disabled:opacity-40"
              >
                Clear Response
              </button>

              <button
                onClick={handleMarkForReviewAndNext}
                className="px-3.5 py-2 text-xs font-semibold text-purple-900 bg-purple-50 hover:bg-purple-100 rounded-lg border border-purple-200 transition-colors"
              >
                Mark for Review & Next
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={advancePrev}
                disabled={currentIdx === 0}
                className="px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded-lg border border-slate-300 transition-colors disabled:opacity-40 flex items-center gap-1"
              >
                <ChevronLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Previous</span>
              </button>

              <button
                onClick={handleSaveAndNext}
                className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1"
              >
                <span>Save & Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Right: Question Palette (Desktop permanent, Mobile drawer) */}
        <aside
          className={`w-80 bg-slate-50 border-l border-slate-200 flex flex-col shrink-0 lg:static fixed inset-y-0 right-0 z-40 transform transition-transform ${
            isPaletteOpenMobile ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
          }`}
        >
          {/* Palette Top / Mobile Close */}
          <div className="p-4 border-b border-slate-200 bg-white flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Question Palette
            </h3>
            <button
              onClick={() => setIsPaletteOpenMobile(false)}
              className="lg:hidden p-1 text-slate-400 hover:text-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Legend Table */}
          <div className="p-4 border-b border-slate-200 bg-white space-y-2 text-[11px] text-slate-600">
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-emerald-600 text-white flex items-center justify-center font-bold text-[10px]">
                  {answeredCount}
                </span>
                <span>Answered</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-rose-600 text-white flex items-center justify-center font-bold text-[10px]">
                  {notAnsweredCount}
                </span>
                <span>Not Answered</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-purple-600 text-white flex items-center justify-center font-bold text-[10px]">
                  {markedCount}
                </span>
                <span>Marked Review</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-[10px]">
                  {notVisitedCount}
                </span>
                <span>Not Visited</span>
              </div>
            </div>
          </div>

          {/* Numbered Questions Grid */}
          <div className="flex-1 p-4 overflow-y-auto">
            <p className="text-[11px] font-semibold text-slate-500 mb-2.5">
              Choose a question to view:
            </p>
            <div className="grid grid-cols-5 gap-2">
              {testQuestions.map((q, idx) => {
                const status = getQuestionStatus(q.id);
                const isCurrent = currentIdx === idx;

                let btnStyle = 'bg-slate-200 text-slate-700 hover:bg-slate-300';
                if (status === 'answered_and_marked') {
                  btnStyle = 'bg-purple-700 text-white ring-2 ring-emerald-500';
                } else if (status === 'marked') {
                  btnStyle = 'bg-purple-600 text-white';
                } else if (status === 'answered') {
                  btnStyle = 'bg-emerald-600 text-white';
                } else if (status === 'not_answered') {
                  btnStyle = 'bg-rose-600 text-white';
                }

                return (
                  <button
                    key={q.id}
                    onClick={() => jumpToQuestion(idx)}
                    className={`h-9 rounded-lg text-xs font-bold transition-all relative flex items-center justify-center ${btnStyle} ${
                      isCurrent ? 'ring-2 ring-blue-600 ring-offset-1' : ''
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Palette Footer Submit */}
          <div className="p-4 bg-white border-t border-slate-200">
            <button
              onClick={() => setIsSubmitModalOpen(true)}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs flex items-center justify-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Submit Test</span>
            </button>
          </div>
        </aside>
      </div>

      {/* Submit Confirmation Dialog */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">
                Submit Examination?
              </h3>
              <button
                onClick={() => setIsSubmitModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to end the test? Once submitted, your answers will be evaluated and your detailed scorecard with rank prediction will be generated.
            </p>

            {/* Summary tally */}
            <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200">
              <div>
                <span className="text-slate-500 block text-[11px]">Answered</span>
                <span className="font-bold text-emerald-700 tabular-nums">{answeredCount}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Unanswered</span>
                <span className="font-bold text-rose-700 tabular-nums">{notAnsweredCount}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Marked for Review</span>
                <span className="font-bold text-purple-700 tabular-nums">{markedCount}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Time Remaining</span>
                <span className="font-bold text-amber-700 font-mono tabular-nums">{formatTimer(remainingSeconds)}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setIsSubmitModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-lg"
              >
                Return to Test
              </button>
              <button
                onClick={() => {
                  setIsSubmitModalOpen(false);
                  handleSubmitTest(false);
                }}
                className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs"
              >
                Yes, Final Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
