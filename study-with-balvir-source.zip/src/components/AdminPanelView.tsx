import React, { useState } from 'react';
import {
  Shield,
  Plus,
  Trash2,
  Edit,
  CheckCircle2,
  Lock,
  Unlock,
  BookOpen,
  FileQuestion,
  CheckSquare,
  RotateCcw,
  AlertTriangle,
  X,
  Search,
  Filter
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EXAM_CATEGORIES } from '../data/mockData';
import { ExamCategory, Question, MockTest, StudyNote } from '../types';

export const AdminPanelView: React.FC = () => {
  const {
    currentUser,
    questions,
    mockTests,
    studyNotes,
    addQuestion,
    deleteQuestion,
    addMockTest,
    toggleTestPremium,
    deleteMockTest,
    addStudyNote,
    deleteStudyNote,
    resetAllDataToDefault,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'questions' | 'tests' | 'notes'>('questions');
  const [isAddQuestionModalOpen, setIsAddQuestionModalOpen] = useState(false);
  const [isAddTestModalOpen, setIsAddTestModalOpen] = useState(false);
  const [isAddNoteModalOpen, setIsAddNoteModalOpen] = useState(false);
  const [questionSearch, setQuestionSearch] = useState('');

  // Form states for adding question
  const [qExam, setQExam] = useState<ExamCategory>('bpsc_tre');
  const [qSubject, setQSubject] = useState('Teaching Aptitude & CDP');
  const [qEn, setQEn] = useState('');
  const [qHi, setQHi] = useState('');
  const [optEn, setOptEn] = useState<[string, string, string, string, string]>([
    '', '', '', '', 'More than one of the above / None of the above'
  ]);
  const [optHi, setOptHi] = useState<[string, string, string, string, string]>([
    '', '', '', '', 'उपर्युक्त में से एक से अधिक / उपर्युक्त में से कोई नहीं'
  ]);
  const [correctIdx, setCorrectIdx] = useState<number>(0);
  const [expEn, setExpEn] = useState('');
  const [expHi, setExpHi] = useState('');
  const [difficulty, setDifficulty] = useState<'Easy' | 'Moderate' | 'Hard'>('Moderate');
  const [yearTag, setYearTag] = useState('BPSC TRE 2026 Expected');

  // Form states for adding test
  const [testTitle, setTestTitle] = useState('');
  const [testHindiTitle, setTestHindiTitle] = useState('');
  const [testExam, setTestExam] = useState<ExamCategory>('bpsc_tre');
  const [testDuration, setTestDuration] = useState(30);
  const [testMarks, setTestMarks] = useState(50);
  const [testNeg, setTestNeg] = useState(0);
  const [testIsPremium, setTestIsPremium] = useState(false);
  const [testPrice, setTestPrice] = useState(199);
  const [testDescEn, setTestDescEn] = useState('');
  const [testDescHi, setTestDescHi] = useState('');

  // Form states for adding note
  const [noteTitleEn, setNoteTitleEn] = useState('');
  const [noteTitleHi, setNoteTitleHi] = useState('');
  const [noteExam, setNoteExam] = useState<ExamCategory>('bpsc_tre');
  const [noteSubject, setNoteSubject] = useState('Bihar Special GK');
  const [noteTime, setNoteTime] = useState(8);
  const [noteKeyPointsEn, setNoteKeyPointsEn] = useState('');
  const [noteKeyPointsHi, setNoteKeyPointsHi] = useState('');
  const [noteContentEn, setNoteContentEn] = useState('');
  const [noteContentHi, setNoteContentHi] = useState('');

  // Handlers
  const handleCreateQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!qEn.trim() || !qHi.trim()) {
      showToast('Please provide question text in both English and Hindi', 'warning');
      return;
    }

    addQuestion({
      examCategory: qExam,
      subject: qSubject,
      questionEn: qEn,
      questionHi: qHi,
      optionsEn: optEn,
      optionsHi: optHi,
      correctOptionIndex: correctIdx,
      explanationEn: expEn,
      explanationHi: expHi,
      difficulty,
      yearTag,
      isBPSC5thOptionStandard: optEn[4].includes('More than one')
    });

    setIsAddQuestionModalOpen(false);
    // Reset inputs
    setQEn('');
    setQHi('');
    setExpEn('');
    setExpHi('');
  };

  const handleCreateMockTest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testTitle.trim()) return;

    // Default to questions matching this exam
    const matchingQIds = questions
      .filter((q) => q.examCategory === testExam)
      .map((q) => q.id);

    addMockTest({
      title: testTitle,
      hindiTitle: testHindiTitle || testTitle,
      examCategory: testExam,
      durationMinutes: testDuration,
      totalMarks: testMarks,
      passMarks: Math.round(testMarks * 0.4),
      negativeMarking: testNeg,
      isPremium: testIsPremium,
      priceInr: testIsPremium ? testPrice : undefined,
      difficulty: 'Exam Level',
      descriptionEn: testDescEn || 'Standard curriculum test series covering recent exam patterns.',
      descriptionHi: testDescHi || 'आधिकारिक परीक्षा पैटर्न पर आधारित प्रश्न पत्र।',
      questionIds: matchingQIds.length > 0 ? matchingQIds : questions.map((q) => q.id)
    });

    setIsAddTestModalOpen(false);
    setTestTitle('');
    setTestHindiTitle('');
  };

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitleEn.trim() || !noteTitleHi.trim()) return;

    addStudyNote({
      examCategory: noteExam,
      subject: noteSubject,
      titleEn: noteTitleEn,
      titleHi: noteTitleHi,
      readTimeMinutes: noteTime,
      isFree: true,
      publishedDate: 'Just Now',
      author: 'Balvir Sir',
      keyPointsEn: noteKeyPointsEn.split('\n').filter((s) => s.trim().length > 0),
      keyPointsHi: noteKeyPointsHi.split('\n').filter((s) => s.trim().length > 0),
      contentEn: noteContentEn,
      contentHi: noteContentHi
    });

    setIsAddNoteModalOpen(false);
    setNoteTitleEn('');
    setNoteTitleHi('');
    setNoteContentEn('');
    setNoteContentHi('');
  };

  const filteredQuestions = questions.filter((q) => {
    if (questionSearch.trim()) {
      const s = questionSearch.toLowerCase();
      return (
        q.questionEn.toLowerCase().includes(s) ||
        q.questionHi.includes(s) ||
        q.subject.toLowerCase().includes(s)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 pb-16">
      {/* Admin Top Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold">
            <Shield className="w-3.5 h-3.5" />
            <span>Master Educator Portal · balvirjee@gmail.com</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white">
            Content Management & Test Administration
          </h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Create and edit 5-option questions, manage mock test duration and INR pricing, publish study notes, and reset curriculum defaults.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={resetAllDataToDefault}
            className="px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors"
            title="Reset data back to seed state"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo Data</span>
          </button>
        </div>
      </div>

      {/* 4 Summary Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Questions in Bank
          </span>
          <div className="text-2xl font-extrabold text-blue-700 tabular-nums">
            {questions.length}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">5-Option Verified MCQs</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Mock Tests
          </span>
          <div className="text-2xl font-extrabold text-slate-900 tabular-nums">
            {mockTests.length}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Free & Premium Mocks</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Study Notes
          </span>
          <div className="text-2xl font-extrabold text-emerald-700 tabular-nums">
            {studyNotes.length}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Bilingual Chapters</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Total Attempts
          </span>
          <div className="text-2xl font-extrabold text-amber-600 tabular-nums">
            {mockTests.reduce((a, b) => a + b.attemptsCount, 0).toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Aspirant Submissions</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveTab('questions')}
          className={`py-3 px-6 text-xs font-bold border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'questions'
              ? 'border-blue-600 text-blue-700 bg-white'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileQuestion className="w-4 h-4" />
          <span>Manage Questions ({questions.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('tests')}
          className={`py-3 px-6 text-xs font-bold border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'tests'
              ? 'border-blue-600 text-blue-700 bg-white'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <CheckSquare className="w-4 h-4" />
          <span>Manage Mock Tests ({mockTests.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('notes')}
          className={`py-3 px-6 text-xs font-bold border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'notes'
              ? 'border-blue-600 text-blue-700 bg-white'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Manage Study Notes ({studyNotes.length})</span>
        </button>
      </div>

      {/* Tab: Manage Questions */}
      {activeTab === 'questions' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search questions by text or subject..."
                value={questionSearch}
                onChange={(e) => setQuestionSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <button
              onClick={() => setIsAddQuestionModalOpen(true)}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add 5-Option Question</span>
            </button>
          </div>

          {/* Questions table */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                    <th className="py-3 px-4">Exam / Subject</th>
                    <th className="py-3 px-4">Question Preview (Hindi & English)</th>
                    <th className="py-3 px-4">Correct</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredQuestions.map((q) => (
                    <tr key={q.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="font-bold text-blue-700 block uppercase text-[11px]">
                          {q.examCategory.replace('_', ' ')}
                        </span>
                        <span className="text-slate-500 text-[11px]">{q.subject}</span>
                      </td>
                      <td className="py-3 px-4 max-w-md">
                        <p className="font-semibold text-slate-900 line-clamp-1">{q.questionHi}</p>
                        <p className="text-slate-500 text-[11px] line-clamp-1">{q.questionEn}</p>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                          Option {['A', 'B', 'C', 'D', 'E'][q.correctOptionIndex]}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={() => deleteQuestion(q.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                          title="Delete question"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Manage Mock Tests */}
      {activeTab === 'tests' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button
              onClick={() => setIsAddTestModalOpen(true)}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Mock Test</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockTests.map((t) => (
              <div
                key={t.id}
                className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toggleTestPremium(t.id)}
                      className={`px-2.5 py-0.5 rounded text-[11px] font-bold flex items-center gap-1 transition-colors ${
                        t.isPremium
                          ? 'bg-amber-100 text-amber-800 border border-amber-300'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                      title="Click to toggle Free / Premium status"
                    >
                      {t.isPremium ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                      <span>{t.isPremium ? `PREMIUM (₹${t.priceInr || 199})` : 'FREE TEST'}</span>
                    </button>
                    <span className="text-slate-400 text-xs uppercase font-medium">{t.examCategory}</span>
                  </div>

                  <button
                    onClick={() => deleteMockTest(t.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <h3 className="text-sm font-bold text-slate-900">{t.title}</h3>

                <div className="text-xs text-slate-500 flex items-center gap-4">
                  <span>{t.durationMinutes} Mins</span>
                  <span>{t.totalMarks} Marks</span>
                  <span>{t.questionIds.length} Questions</span>
                  <span>{t.attemptsCount} Attempts</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Manage Study Notes */}
      {activeTab === 'notes' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button
              onClick={() => setIsAddNoteModalOpen(true)}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Bilingual Study Note</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {studyNotes.map((n) => (
              <div
                key={n.id}
                className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-2 flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                      {n.subject}
                    </span>
                    <button
                      onClick={() => deleteStudyNote(n.id)}
                      className="p-1 text-slate-400 hover:text-rose-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900">{n.titleHi}</h4>
                  <p className="text-xs text-slate-500 line-clamp-2">{n.titleEn}</p>
                </div>
                <div className="pt-2 text-[11px] text-slate-400 border-t border-slate-100 flex justify-between">
                  <span>{n.readTimeMinutes} min read</span>
                  <span>Published: {n.publishedDate}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Add 5-Option Question */}
      {isAddQuestionModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <h3 className="text-sm font-bold">Add 5-Option MCQ to Question Bank</h3>
              <button
                onClick={() => setIsAddQuestionModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateQuestion} className="p-6 space-y-4 overflow-y-auto text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Exam Category</label>
                  <select
                    value={qExam}
                    onChange={(e) => setQExam(e.target.value as ExamCategory)}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    {EXAM_CATEGORIES.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Subject</label>
                  <input
                    type="text"
                    required
                    value={qSubject}
                    onChange={(e) => setQSubject(e.target.value)}
                    placeholder="e.g. Teaching Aptitude, Bihar GK"
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Question (Hindi)</label>
                <textarea
                  required
                  rows={2}
                  value={qHi}
                  onChange={(e) => setQHi(e.target.value)}
                  placeholder="प्रश्न हिंदी में लिखें..."
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Question (English)</label>
                <textarea
                  required
                  rows={2}
                  value={qEn}
                  onChange={(e) => setQEn(e.target.value)}
                  placeholder="Write question in English..."
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              {/* 5 Options Inputs */}
              <div className="space-y-2">
                <label className="block font-bold text-slate-900 uppercase tracking-wider text-[11px]">
                  5 Options (A, B, C, D, E) — Select Correct Answer:
                </label>
                {['A', 'B', 'C', 'D', 'E'].map((letter, idx) => (
                  <div key={idx} className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200">
                    <input
                      type="radio"
                      name="correctOption"
                      checked={correctIdx === idx}
                      onChange={() => setCorrectIdx(idx)}
                      className="w-4 h-4 text-blue-600 shrink-0"
                    />
                    <span className="font-bold text-slate-800 w-4">{letter}</span>
                    <input
                      type="text"
                      placeholder={`Hindi Option ${letter}`}
                      value={optHi[idx]}
                      onChange={(e) => {
                        const copy = [...optHi] as [string, string, string, string, string];
                        copy[idx] = e.target.value;
                        setOptHi(copy);
                      }}
                      className="flex-1 p-1.5 border border-slate-300 rounded bg-white text-xs"
                    />
                    <input
                      type="text"
                      placeholder={`English Option ${letter}`}
                      value={optEn[idx]}
                      onChange={(e) => {
                        const copy = [...optEn] as [string, string, string, string, string];
                        copy[idx] = e.target.value;
                        setOptEn(copy);
                      }}
                      className="flex-1 p-1.5 border border-slate-300 rounded bg-white text-xs"
                    />
                  </div>
                ))}
              </div>

              {/* Explanations */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">विस्तृत व्याख्या (Hindi)</label>
                  <textarea
                    rows={2}
                    value={expHi}
                    onChange={(e) => setExpHi(e.target.value)}
                    placeholder="विस्तार से कारण स्पष्ट करें..."
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Explanation (English)</label>
                  <textarea
                    rows={2}
                    value={expEn}
                    onChange={(e) => setExpEn(e.target.value)}
                    placeholder="Explain why this option is correct..."
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsAddQuestionModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg"
                >
                  Save Question
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Mock Test */}
      {isAddTestModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-bold">Publish New Mock Test</h3>
              <button onClick={() => setIsAddTestModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateMockTest} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Test Title (English)</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. BPSC TRE 4.0 Special Mock #2"
                  value={testTitle}
                  onChange={(e) => setTestTitle(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">शीर्षक (Hindi)</label>
                <input
                  type="text"
                  placeholder="e.g. BPSC टी.आर.ई. 4.0 स्पेशल मॉक #2"
                  value={testHindiTitle}
                  onChange={(e) => setTestHindiTitle(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Duration (Min)</label>
                  <input
                    type="number"
                    value={testDuration}
                    onChange={(e) => setTestDuration(Number(e.target.value))}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Total Marks</label>
                  <input
                    type="number"
                    value={testMarks}
                    onChange={(e) => setTestMarks(Number(e.target.value))}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Negative Mark</label>
                  <input
                    type="number"
                    step="0.01"
                    value={testNeg}
                    onChange={(e) => setTestNeg(Number(e.target.value))}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="prem"
                  checked={testIsPremium}
                  onChange={(e) => setTestIsPremium(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded"
                />
                <label htmlFor="prem" className="font-semibold text-slate-700">
                  Mark as Premium Test (Requires Student Pass)
                </label>
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddTestModalOpen(false)}
                  className="px-4 py-2 text-slate-600"
                >
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg">
                  Publish Test
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Study Note */}
      {isAddNoteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-bold">Add Bilingual Study Chapter</h3>
              <button onClick={() => setIsAddNoteModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateNote} className="p-6 space-y-4 overflow-y-auto text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Title (Hindi)</label>
                  <input
                    type="text"
                    required
                    placeholder="अध्याय का नाम..."
                    value={noteTitleHi}
                    onChange={(e) => setNoteTitleHi(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Title (English)</label>
                  <input
                    type="text"
                    required
                    placeholder="Chapter Title..."
                    value={noteTitleEn}
                    onChange={(e) => setNoteTitleEn(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Chapter Content (Hindi)</label>
                <textarea
                  rows={4}
                  required
                  value={noteContentHi}
                  onChange={(e) => setNoteContentHi(e.target.value)}
                  placeholder="सम्पूर्ण अध्याय विवरण..."
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Chapter Content (English)</label>
                <textarea
                  rows={4}
                  required
                  value={noteContentEn}
                  onChange={(e) => setNoteContentEn(e.target.value)}
                  placeholder="Full chapter description..."
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddNoteModalOpen(false)}
                  className="px-4 py-2 text-slate-600"
                >
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg">
                  Save & Publish
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
