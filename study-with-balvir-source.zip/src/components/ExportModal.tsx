import React, { useState } from 'react';
import {
  Download,
  Copy,
  Check,
  ExternalLink,
  X,
  FileCode,
  Smartphone,
  FolderArchive,
  Info
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const { showToast } = useApp();
  const [copiedLink, setCopiedLink] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  if (!isOpen) return null;

  // The direct public URLs
  const directUrl = `${window.location.origin}/study-with-balvir-source.zip`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(directUrl);
      setCopiedLink(true);
      showToast('Download link copied! Paste into Chrome address bar.', 'success');
      setTimeout(() => setCopiedLink(false), 3000);
    } catch {
      showToast('Could not copy automatically. Link: ' + directUrl, 'info');
    }
  };

  // Robust client-side Blob download (bypasses iframe navigation sandboxing on mobile)
  const handleBlobDownload = async () => {
    try {
      setIsDownloading(true);
      showToast('Preparing ZIP download...', 'info');

      const response = await fetch('/study-with-balvir-source.zip');
      if (!response.ok) {
        throw new Error('Failed to fetch zip');
      }

      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = 'study-with-balvir-source.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      setTimeout(() => window.URL.revokeObjectURL(blobUrl), 2000);
      showToast('Download started successfully!', 'success');
    } catch (err) {
      console.error(err);
      showToast('Download blocked by iframe. Please use Option 2 or 3 below.', 'warning');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/75 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-xl">
              <FolderArchive className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold">Download Complete Project Source Code</h2>
              <p className="text-[11px] text-blue-200">Study with Balvir — ZIP Archive (1.2 MB)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto text-xs text-slate-700">
          {/* Method 1: Mobile-friendly Blob trigger */}
          <div className="p-4 rounded-xl border-2 border-emerald-500 bg-emerald-50/50 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-900 uppercase text-[11px] tracking-wider">
                Method 1: Direct Mobile Download
              </span>
              <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                Recommended
              </span>
            </div>
            <p className="text-slate-600 leading-relaxed text-xs">
              Uses an in-memory Blob trigger to bypass mobile Chrome iframe restrictions and save <code className="bg-emerald-100 px-1 py-0.5 rounded text-emerald-950">study-with-balvir-source.zip</code> directly to your device's Downloads folder.
            </p>
            <button
              onClick={handleBlobDownload}
              disabled={isDownloading}
              className="w-full min-h-[46px] py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>{isDownloading ? 'Downloading...' : 'Tap to Download ZIP File (1.2 MB)'}</span>
            </button>
          </div>

          {/* Method 2: Copy Direct Link to paste in Android Chrome */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2.5">
            <span className="font-bold text-slate-900 uppercase text-[11px] tracking-wider block">
              Method 2: Open in Android Chrome Address Bar
            </span>
            <p className="text-slate-600 leading-relaxed text-xs">
              If your mobile browser blocks iframe downloads, copy this direct URL and paste it into a new tab in Android Chrome:
            </p>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={directUrl}
                className="flex-1 p-2 bg-white border border-slate-300 rounded-lg text-[11px] font-mono text-slate-700 truncate"
              />
              <button
                onClick={handleCopyLink}
                className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shrink-0 flex items-center gap-1 transition-colors"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Method 3: Google AI Studio Native Export Steps */}
          <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/60 space-y-2.5">
            <div className="flex items-center gap-2 text-blue-950 font-bold text-xs uppercase tracking-wider">
              <Smartphone className="w-4 h-4 text-blue-700" />
              <span>Method 3: Native Google AI Studio Export (Android Chrome)</span>
            </div>
            <p className="text-slate-700 leading-relaxed text-xs">
              Google AI Studio provides a native built-in project exporter:
            </p>
            <ol className="list-decimal pl-5 space-y-1.5 text-xs text-slate-700">
              <li>
                In Google AI Studio on your Android phone, look at the <strong>top app header</strong> (above this preview).
              </li>
              <li>
                Tap the <strong>three dots menu (⋮)</strong> or the <strong>Share / Export</strong> button in the top-right corner.
              </li>
              <li>
                Select <strong>"Export to GitHub"</strong> or <strong>"Download project"</strong> to save the complete repository as a ZIP archive to your phone.
              </li>
              <li>
                You can also tap the <strong>&quot;Code&quot; / &quot;&lt;/&gt;&quot; tab</strong> in AI Studio to view and copy individual files directly.
              </li>
            </ol>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded-lg border border-slate-300"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
