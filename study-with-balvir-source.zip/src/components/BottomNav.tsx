import React from 'react';
import { Home, FileQuestion, BookOpen, User, CheckSquare } from 'lucide-react';
import { useApp, AppView } from '../context/AppContext';

export const BottomNav: React.FC = () => {
  const { currentView, setCurrentView, activeTest } = useApp();

  // If live mock test is active, hide bottom navigation to maximize test space
  if (activeTest) return null;

  const items: { view: AppView; label: string; icon: React.FC<{ className?: string }> }[] = [
    { view: 'home', label: 'Home', icon: Home },
    { view: 'mock_tests', label: 'Mocks', icon: CheckSquare },
    { view: 'practice', label: '5-Options', icon: FileQuestion },
    { view: 'notes', label: 'Notes', icon: BookOpen },
    { view: 'dashboard', label: 'Profile', icon: User },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200">
      <div className="grid grid-cols-5 h-16 max-w-lg mx-auto">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.view;
          return (
            <button
              key={item.view}
              onClick={() => setCurrentView(item.view)}
              className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] w-full transition-colors ${
                isActive ? 'text-blue-700 font-bold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              <span className="text-[10px] tracking-tight mt-1 truncate">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
