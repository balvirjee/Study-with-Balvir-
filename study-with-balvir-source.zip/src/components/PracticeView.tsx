import React, { useState } from 'react';
import {
  HelpCircle,
  Bookmark,
  CheckCircle,
  XCircle,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Languages,
  BookOpen,
  Filter,
  Check,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EXAM_CATEGORIES } from '../data/mockData';
import { ExamCategory, Question } from '../types';

export const PracticeView: React.FC = () => {
  const {
    questions,
    targetExam,
    setTargetExam,
    currentUser,
    toggleBookmark,
    appLanguage,
    setAppLanguage,
    setCurrentView
  } = useApp();

  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [filterType, setFilterType] = useState<'all' | 'bookmarked'>('all');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState<boolean>(false);
  const [localLang, setLocalLang] = useState<'hi' | 'en'>(appLanguage);

  // Filter questions based on exam, subject, and filterType
  const filteredQuestions = questions.filter((q) => {
    if (q.examCategory !== targetExam) return false;
    if (selectedSubject !== 'all' && q.subject !== selectedSubject) return false;
    if (filterType === 'bookmarked') {
      return currentUser?.bookmarks.includes(q.id);
    }
    return true;
  });

  const activeCategory = EXAM_CATEGORIES.find((c) => c.id === targetExam) || EXAM_CATEGORIES[0];
  const currentQ: Question | undefined = filteredQuestions[currentIndex];

  const handleOptionSelect = (index: number) => {
    if (isAnswerChecked) return; // Prevent changing after checking
    setSelectedOption(index);
  };

  const handleCheckAnswer = () => {
    if (selectedOption === null) return;
    setIsAnswerChecked(true);
  };

  const handleNext = () => {
    if (currentIndex < filteredQuestions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
    }
  };

  const handleResetCurrent = () => {
    setSelectedOption(null);
    setIsAnswerChecked(false);
  };

  const isBookmarked = currentQ && currentUser?.bookmarks.includes(currentQ.id);

  const optionLetters = ['A', 'B', 'C', 'D', 'E'];

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Top Controls / Filters */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-slate-900">
                5-Option MCQ Practice Arena
              </h1>
              <span className="text-[11px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                {activeCategory.badge}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Exam-accurate practice with 5 options (A, B, C, D, E) and detailed bilingual rationale
            </p>
          </div>

          {/* Language Toggle for this question */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLocalLang(localLang === 'hi' ? 'en' : 'hi')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
            >
              <Languages className="w-3.5 h-3.5 text-blue-700" />
              <span>Language: {localLang === 'hi' ? 'हिंदी' : 'English'}</span>
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
          {/* Exam switcher */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 max-w-full">
            {EXAM_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setTargetExam(cat.id);
                  setSelectedSubject('all');
                  setCurrentIndex(0);
                  setSelectedOption(null);
                  setIsAnswerChecked(false);
                }}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors ${
                  targetExam === cat.id
                    ? 'bg-blue-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat.badge}
              </button>
            ))}
          </div>

          <div className="h-4 w-px bg-slate-200 hidden sm:block mx-1" />

          {/* Bookmarks filter */}
          <button
            onClick={() => {
              setFilterType(filterType === 'all' ? 'bookmarked' : 'all');
              setCurrentIndex(0);
              setSelectedOption(null);
              setIsAnswerChecked(false);
            }}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1 ${
              filterType === 'bookmarked'
                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900'
            }`}
          >
            <Bookmark className="w-3 h-3" />
            <span>Bookmarked ({currentUser?.bookmarks.length || 0})</span>
          </button>
        </div>

        {/* Subject pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => {
              setSelectedSubject('all');
              setCurrentIndex(0);
              setSelectedOption(null);
              setIsAnswerChecked(false);
            }}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold whitespace-nowrap transition-colors ${
              selectedSubject === 'all'
                ? 'bg-slate-800 text-white'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            All Subjects
          </button>
          {activeCategory.subjects.map((sub) => (
            <button
              key={sub}
              onClick={() => {
                setSelectedSubject(sub);
                setCurrentIndex(0);
                setSelectedOption(null);
                setIsAnswerChecked(false);
              }}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium whitespace-nowrap transition-colors ${
                selectedSubject === sub
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {sub}
            </button>
          ))}
        </div>
      </div>

      {/* Question Card Container */}
      {filteredQuestions.length === 0 ? (
        <div className="p-12 text-center bg-white border border-slate-200 rounded-2xl space-y-3">
          <AlertCircle className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">No Questions Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {filterType === 'bookmarked'
              ? 'You have not bookmarked any questions in this category yet. Click the bookmark icon on any question to save it.'
              : 'No questions match the current filter. Try selecting "All Subjects" or a different exam.'}
          </p>
          <button
            onClick={() => {
              setFilterType('all');
              setSelectedSubject('all');
            }}
            className="px-4 py-2 text-xs font-semibold text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100"
          >
            Reset Filters
          </button>
        </div>
      ) : currentQ ? (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
          {/* Card Top Header */}
          <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-slate-900 bg-white border border-slate-200 px-2.5 py-1 rounded-md tabular-nums">
                Q {currentIndex + 1} of {filteredQuestions.length}
              </span>
              <span className="text-xs font-medium text-slate-600 truncate max-w-[200px] sm:max-w-xs">
                {currentQ.subject}
              </span>
              {currentQ.yearTag && (
                <span className="hidden sm:inline text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                  {currentQ.yearTag}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => toggleBookmark(currentQ.id)}
                className={`p-2 rounded-lg border transition-colors ${
                  isBookmarked
                    ? 'bg-amber-50 text-amber-600 border-amber-300'
                    : 'bg-white text-slate-400 border-slate-200 hover:text-slate-700'
                }`}
                title={isBookmarked ? 'Remove bookmark' : 'Bookmark question'}
              >
                <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-500' : ''}`} />
              </button>

              <button
                onClick={handleResetCurrent}
                className="p-2 text-slate-400 hover:text-slate-700 rounded-lg border border-slate-200 bg-white"
                title="Reset this question"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Question Text */}
          <div className="p-6 space-y-6">
            <div className="space-y-2">
              <p className="text-sm sm:text-base font-semibold text-slate-900 leading-relaxed">
                {localLang === 'hi' ? currentQ.questionHi : currentQ.questionEn}
              </p>
              {/* Show second language subtly if helpful */}
              <p className="text-xs text-slate-500 leading-normal italic">
                {localLang === 'hi' ? currentQ.questionEn : currentQ.questionHi}
              </p>
            </div>

            {/* 5 Options (A, B, C, D, E) */}
            <div className="space-y-2.5">
              {(localLang === 'hi' ? currentQ.optionsHi : currentQ.optionsEn).map((optText, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = idx === currentQ.correctOptionIndex;
                const letter = optionLetters[idx];

                // Styling logic after answer is checked
                let optionStyle = 'border-slate-200 bg-white hover:border-blue-300';
                let circleStyle = 'border-slate-300 text-slate-700 bg-slate-50';

                if (isAnswerChecked) {
                  if (isCorrect) {
                    optionStyle = 'border-emerald-500 bg-emerald-50/70 text-emerald-950 font-medium ring-1 ring-emerald-500';
                    circleStyle = 'border-emerald-600 bg-emerald-600 text-white font-bold';
                  } else if (isSelected && !isCorrect) {
                    optionStyle = 'border-rose-400 bg-rose-50 text-rose-950';
                    circleStyle = 'border-rose-500 bg-rose-500 text-white';
                  } else {
                    optionStyle = 'border-slate-200 bg-slate-50/60 opacity-60';
                  }
                } else if (isSelected) {
                  optionStyle = 'border-blue-600 bg-blue-50/60 ring-1 ring-blue-600';
                  circleStyle = 'border-blue-600 bg-blue-600 text-white font-bold';
                }

                // If Option E is standard BPSC 5th option, add distinct cue
                const isOptionE = idx === 4;

                return (
                  <div
                    key={idx}
                    onClick={() => handleOptionSelect(idx)}
                    className={`p-3.5 sm:p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${optionStyle}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-7 h-7 rounded-lg border flex items-center justify-center text-xs shrink-0 ${circleStyle}`}>
                        {letter}
                      </div>
                      <span className="text-xs sm:text-sm text-slate-800 leading-snug">
                        {optText}
                      </span>
                    </div>

                    {isAnswerChecked && isCorrect && (
                      <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                    )}
                    {isAnswerChecked && isSelected && !isCorrect && (
                      <XCircle className="w-5 h-5 text-rose-500 shrink-0" />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Check Answer CTA or Explanation Box */}
            {!isAnswerChecked ? (
              <div className="pt-2 flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  {selectedOption === null
                    ? 'Select an option (A, B, C, D, or E) to check answer'
                    : `Option (${optionLetters[selectedOption]}) selected`}
                </span>
                <button
                  onClick={handleCheckAnswer}
                  disabled={selectedOption === null}
                  className={`px-5 py-2.5 text-xs font-bold rounded-xl transition-all shadow-xs ${
                    selectedOption !== null
                      ? 'bg-blue-600 hover:bg-blue-700 text-white'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  Check Answer
                </button>
              </div>
            ) : (
              <div className="mt-4 p-5 rounded-xl border border-blue-200 bg-blue-50/40 space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {selectedOption === currentQ.correctOptionIndex ? (
                      <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-md">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>Correct Answer! (+1 Mark)</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5 text-xs font-bold text-rose-700 bg-rose-100 px-2.5 py-1 rounded-md">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Incorrect Choice</span>
                      </span>
                    )}
                    <span className="text-xs text-slate-600 font-semibold">
                      Correct: Option ({optionLetters[currentQ.correctOptionIndex]})
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-slate-700 leading-relaxed">
                  <p className="font-bold text-slate-900 text-xs">
                    {localLang === 'hi' ? 'विस्तृत व्याख्या (Explanation):' : 'Detailed Explanation:'}
                  </p>
                  <p className="text-slate-800">
                    {localLang === 'hi' ? currentQ.explanationHi : currentQ.explanationEn}
                  </p>
                  {/* Subtle translation of explanation */}
                  <p className="text-[11px] text-slate-500 pt-1 border-t border-blue-200/50 italic">
                    {localLang === 'hi' ? currentQ.explanationEn : currentQ.explanationHi}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Card Footer: Navigation */}
          <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
            <button
              onClick={handlePrev}
              disabled={currentIndex === 0}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
                currentIndex > 0
                  ? 'text-slate-700 hover:bg-slate-200 bg-white border border-slate-200'
                  : 'text-slate-300 cursor-not-allowed bg-slate-100'
              }`}
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <span className="text-xs text-slate-500 font-medium tabular-nums">
              {currentIndex + 1} / {filteredQuestions.length}
            </span>

            <button
              onClick={handleNext}
              disabled={currentIndex === filteredQuestions.length - 1}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
                currentIndex < filteredQuestions.length - 1
                  ? 'text-white bg-blue-600 hover:bg-blue-700 shadow-xs'
                  : 'text-slate-300 cursor-not-allowed bg-slate-100'
              }`}
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
};
