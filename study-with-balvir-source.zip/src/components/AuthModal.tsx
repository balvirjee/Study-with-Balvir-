import React, { useState } from 'react';
import { X, User as UserIcon, Lock, Mail, Phone, GraduationCap, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ExamCategory } from '../types';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    loginAsDemoStudent,
    loginAsDemoAdmin,
    loginUser,
    targetExam,
    setTargetExam
  } = useApp();

  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    loginUser(email, name || undefined);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="relative px-6 pt-6 pb-4 bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="absolute top-4 right-4 p-1 text-slate-300 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="inline-flex items-center gap-2 px-2.5 py-1 mb-2 rounded bg-white/15 text-[11px] font-medium tracking-wide">
            <GraduationCap className="w-3.5 h-3.5 text-blue-300" />
            <span>Study with Balvir</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight">
            {activeTab === 'login' ? 'Student & Educator Sign In' : 'Create Free Student Account'}
          </h2>
          <p className="text-xs text-blue-200 mt-1">
            Access 5-option BPSC TRE tests, CTET notes & performance analytics
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-slate-200 bg-slate-50">
          <button
            onClick={() => setActiveTab('login')}
            className={`flex-1 py-3 text-xs font-semibold text-center border-b-2 transition-colors ${
              activeTab === 'login'
                ? 'border-blue-600 text-blue-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => setActiveTab('register')}
            className={`flex-1 py-3 text-xs font-semibold text-center border-b-2 transition-colors ${
              activeTab === 'register'
                ? 'border-blue-600 text-blue-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            New Student Register
          </button>
        </div>

        {/* Quick Demo Logins Banner */}
        <div className="p-4 bg-slate-50 border-b border-slate-200">
          <p className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider mb-2">
            One-Click Demo Access:
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={loginAsDemoStudent}
              className="flex items-center justify-center gap-1.5 px-3 py-2 bg-white border border-blue-200 hover:border-blue-400 text-blue-900 rounded-lg text-xs font-medium shadow-xs transition-colors text-left"
            >
              <UserIcon className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Demo Student</span>
            </button>
            <button
              onClick={loginAsDemoAdmin}
              className="flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-900 text-white hover:bg-slate-800 rounded-lg text-xs font-medium shadow-xs transition-colors text-left"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>Admin (Balvir Sir)</span>
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {activeTab === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Full Name
              </label>
              <div className="relative">
                <UserIcon className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Kumar"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Email Address / User ID
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                type="email"
                required
                placeholder="name@student.in or balvirjee@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              />
            </div>
          </div>

          {activeTab === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Mobile Number (+91)
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="tel"
                  placeholder="98765 43210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Target Examination
            </label>
            <select
              value={targetExam}
              onChange={(e) => setTargetExam(e.target.value as ExamCategory)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent bg-white text-slate-800"
            >
              <option value="bpsc_tre">BPSC TRE (Teacher Recruitment 3.0/4.0)</option>
              <option value="ctet">CTET (Central Teacher Eligibility Test)</option>
              <option value="jtet">JTET (Jharkhand Teacher Eligibility Test)</option>
              <option value="bpsc_cce">BPSC Civil Services (70th/71st CCE)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
          >
            {activeTab === 'login' ? 'Sign In to Student Portal' : 'Register & Start Free Mock Test'}
          </button>

          <p className="text-[11px] text-slate-400 text-center leading-normal">
            By signing in, you agree to Study with Balvir’s mock test honor code and test rules.
          </p>
        </form>
      </div>
    </div>
  );
};
