import React, { useState } from 'react';
import {
  Crown,
  Check,
  ShieldCheck,
  CreditCard,
  Sparkles,
  Info,
  Tag,
  ArrowRight,
  X,
  Lock,
  Smartphone,
  CheckCircle2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PASS_PLANS } from '../data/mockData';
import { PassPlan } from '../types';

export const PricingPassView: React.FC = () => {
  const {
    currentUser,
    unlockPremiumPass,
    setIsAuthModalOpen,
    setIsArchitectureModalOpen,
    appLanguage,
    showToast
  } = useApp();

  const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<PassPlan | null>(null);
  const [couponCode, setCouponCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.trim().toUpperCase() === 'BALVIR10' || couponCode.trim().toUpperCase() === 'TRE2026') {
      setDiscountPercent(10);
      showToast('Coupon applied successfully! 10% discount added.', 'success');
    } else {
      showToast('Invalid coupon code. Try BALVIR10 or TRE2026', 'warning');
    }
  };

  const handleOpenCheckout = (plan: PassPlan) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    setSelectedPlanForCheckout(plan);
    setDiscountPercent(0);
    setCouponCode('');
  };

  const handleCompleteSimulation = () => {
    if (!selectedPlanForCheckout) return;
    unlockPremiumPass(selectedPlanForCheckout.title);
    setSelectedPlanForCheckout(null);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Top Banner */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold">
          <Crown className="w-3.5 h-3.5 text-amber-600 fill-amber-600" />
          <span>Study with Balvir Premium Pass</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
          Crack BPSC TRE, CTET & JTET with Full Test Series
        </h1>
        <p className="text-xs sm:text-sm text-slate-600">
          Affordable student pricing in Indian Rupees (₹). Unlimited 5-option mock tests, All-India rankings, and solutions.
        </p>
      </div>

      {/* Production Integration Architecture Banner */}
      <div className="p-4 sm:p-5 bg-blue-50 border border-blue-200 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-blue-600 text-white rounded-xl shrink-0 mt-0.5">
            <CreditCard className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-blue-950">
              Payment Gateway Integration Notice
            </h3>
            <p className="text-xs text-blue-800 leading-relaxed max-w-2xl">
              Real money payments are not processed in this evaluation prototype. In production, this module connects securely to <strong>Razorpay / Cashfree / PhonePe</strong> with server-side webhook signature verification. Click <strong>"Unlock Pass (Prototype)"</strong> to test all premium features freely.
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsArchitectureModalOpen(true)}
          className="px-3 py-2 text-xs font-semibold text-blue-900 bg-white hover:bg-blue-100 border border-blue-200 rounded-lg whitespace-nowrap shrink-0 transition-colors"
        >
          View Architecture Blueprint
        </button>
      </div>

      {/* Active Pass Status if student already has pass */}
      {currentUser?.hasPremiumPass && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-600" />
            <div>
              <p className="text-xs font-bold text-emerald-950">
                Active Premium Pass: {currentUser.passPlanName || 'All-Access Pass'}
              </p>
              <p className="text-[11px] text-emerald-700">
                Valid until {currentUser.passExpiryDate || 'October 2027'} · All tests unlocked!
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full">
            UNLOCKED
          </span>
        </div>
      )}

      {/* 3 Pricing Cards in Indian Rupees */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {PASS_PLANS.map((plan) => {
          const isCurrentActive = currentUser?.hasPremiumPass && currentUser.passPlanName === plan.title;

          return (
            <div
              key={plan.id}
              className={`bg-white rounded-2xl border transition-all flex flex-col justify-between overflow-hidden ${
                plan.popular
                  ? 'border-blue-600 shadow-lg ring-2 ring-blue-600/30'
                  : 'border-slate-200 shadow-xs hover:border-slate-300'
              }`}
            >
              {plan.popular && (
                <div className="bg-blue-600 text-white text-[11px] font-bold text-center py-1 uppercase tracking-wider">
                  Most Popular for BPSC TRE
                </div>
              )}

              <div className="p-6 space-y-4">
                <div>
                  <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider block mb-1">
                    {plan.targetExamBadge}
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 leading-snug">
                    {appLanguage === 'hi' ? plan.hindiTitle : plan.title}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">Validity: {plan.validity}</p>
                </div>

                {/* Price in INR */}
                <div className="py-2 border-y border-slate-100">
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-extrabold text-slate-900 tabular-nums">
                      ₹{plan.priceInr}
                    </span>
                    <span className="text-xs text-slate-400 line-through tabular-nums">
                      ₹{plan.originalPriceInr}
                    </span>
                    <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                      {Math.round(((plan.originalPriceInr - plan.priceInr) / plan.originalPriceInr) * 100)}% OFF
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 block mt-1">Inclusive of all taxes (GST 18%)</span>
                </div>

                {/* Features List */}
                <ul className="space-y-2.5 text-xs text-slate-700">
                  {(appLanguage === 'hi' ? plan.hindiFeatures : plan.features).map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span className="leading-tight">{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action CTA */}
              <div className="p-6 pt-0">
                {isCurrentActive ? (
                  <button
                    disabled
                    className="w-full py-2.5 text-xs font-bold text-emerald-800 bg-emerald-100 rounded-xl cursor-default flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Already Active</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleOpenCheckout(plan)}
                    className={`w-full py-3 text-xs font-bold rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5 ${
                      plan.popular
                        ? 'bg-blue-600 hover:bg-blue-700 text-white'
                        : 'bg-slate-900 hover:bg-slate-800 text-white'
                    }`}
                  >
                    <span>Unlock Pass for ₹{plan.priceInr}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Free vs Premium Comparison Table */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-900">
          Feature Comparison: Free vs. Premium Pass
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50">
                <th className="py-3 px-4 font-bold text-slate-700">Feature</th>
                <th className="py-3 px-4 font-bold text-slate-700 text-center">Free Student Account</th>
                <th className="py-3 px-4 font-bold text-blue-700 text-center">Premium Pass (₹199 - ₹299)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              <tr>
                <td className="py-3 px-4 font-medium text-slate-800">5-Option Practice Bank</td>
                <td className="py-3 px-4 text-center text-emerald-600 font-semibold">100% Free Access</td>
                <td className="py-3 px-4 text-center text-emerald-600 font-semibold">100% Free Access</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-800">Bilingual Study Notes (Hindi/Eng)</td>
                <td className="py-3 px-4 text-center text-emerald-600 font-semibold">Unlimited Free</td>
                <td className="py-3 px-4 text-center text-emerald-600 font-semibold">Unlimited Free</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-800">Standard Mini Mock Tests</td>
                <td className="py-3 px-4 text-center text-emerald-600 font-semibold">5 Tests Included</td>
                <td className="py-3 px-4 text-center text-emerald-600 font-semibold">50+ Full-Length Mocks</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-800">All-India Rank & Percentile</td>
                <td className="py-3 px-4 text-center text-slate-400">Basic Score</td>
                <td className="py-3 px-4 text-center text-emerald-600 font-semibold">Full Rank & Percentile</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-800">Option E ("None / More Than One") Special Drills</td>
                <td className="py-3 px-4 text-center text-slate-400">Sample Drills</td>
                <td className="py-3 px-4 text-center text-emerald-600 font-semibold">500+ Curated Questions</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-800">Printable Offline PDF Downloads</td>
                <td className="py-3 px-4 text-center text-slate-400">Online Only</td>
                <td className="py-3 px-4 text-center text-emerald-600 font-semibold">Unlimited Downloads</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Simulated Checkout Modal */}
      {selectedPlanForCheckout && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            {/* Header */}
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] text-amber-300 font-bold uppercase tracking-wider block">
                  Simulated Student Checkout
                </span>
                <h3 className="text-base font-bold">
                  {selectedPlanForCheckout.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedPlanForCheckout(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Prototype Notice */}
            <div className="p-4 bg-amber-50 border-b border-amber-200 text-amber-950 text-xs">
              <span className="font-bold">Prototype Sandbox Mode: </span>
              In production, this opens the Razorpay/Cashfree secure modal with real UPI QR codes and card processing. Here, you can test the instant unlock flow risk-free.
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              {/* Payment Method Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Select Payment Method (Simulated):
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('upi')}
                    className={`p-3 rounded-xl border text-center text-xs font-semibold transition-all ${
                      selectedPaymentMethod === 'upi'
                        ? 'border-blue-600 bg-blue-50 text-blue-700'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 mx-auto mb-1 text-blue-600" />
                    <span>UPI (GPay / PhonePe)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('card')}
                    className={`p-3 rounded-xl border text-center text-xs font-semibold transition-all ${
                      selectedPaymentMethod === 'card'
                        ? 'border-blue-600 bg-blue-50 text-blue-700'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 mx-auto mb-1 text-slate-600" />
                    <span>Debit / RuPay Card</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('netbanking')}
                    className={`p-3 rounded-xl border text-center text-xs font-semibold transition-all ${
                      selectedPaymentMethod === 'netbanking'
                        ? 'border-blue-600 bg-blue-50 text-blue-700'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <ShieldCheck className="w-4 h-4 mx-auto mb-1 text-emerald-600" />
                    <span>Net Banking</span>
                  </button>
                </div>
              </div>

              {/* Coupon Code */}
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Coupon code (e.g. BALVIR10)"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200"
                >
                  Apply
                </button>
              </form>

              {/* Price Breakdown */}
              <div className="p-3 bg-slate-50 rounded-xl space-y-2 text-xs text-slate-600 border border-slate-100">
                <div className="flex justify-between">
                  <span>Pass Price</span>
                  <span className="font-semibold tabular-nums">₹{selectedPlanForCheckout.priceInr}</span>
                </div>
                {discountPercent > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>Discount (10%)</span>
                    <span className="tabular-nums">-₹{Math.round(selectedPlanForCheckout.priceInr * 0.1)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>GST (18% included)</span>
                  <span className="tabular-nums">₹{Math.round(selectedPlanForCheckout.priceInr * 0.18)}</span>
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-bold text-slate-900">
                  <span>Total Payable:</span>
                  <span className="tabular-nums">
                    ₹{discountPercent > 0
                      ? Math.round(selectedPlanForCheckout.priceInr * 0.9)
                      : selectedPlanForCheckout.priceInr}
                  </span>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => setSelectedPlanForCheckout(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                onClick={handleCompleteSimulation}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-2"
              >
                <span>Unlock Pass (Instant Simulation)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
