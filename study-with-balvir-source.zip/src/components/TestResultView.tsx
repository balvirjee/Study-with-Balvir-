import React, { useState } from 'react';
import {
  Award,
  Trophy,
  CheckCircle2,
  XCircle,
  Clock,
  Target,
  ArrowLeft,
  RotateCcw,
  Bookmark,
  Languages,
  Check,
  ChevronDown,
  Filter
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Question } from '../types';

export const TestResultView: React.FC = () => {
  const {
    activeResult,
    closeTestResult,
    startMockTest,
    questions,
    currentUser,
    toggleBookmark,
    appLanguage,
    setCurrentView
  } = useApp();

  const [activeTab, setActiveTab] = useState<'analytics' | 'solutions'>('analytics');
  const [solutionFilter, setSolutionFilter] = useState<'all' | 'correct' | 'incorrect' | 'unattempted'>('all');
  const [lang, setLang] = useState<'hi' | 'en'>(appLanguage);

  if (!activeResult) return null;

  // Resolve questions for this test
  const questionMap = new Map<string, Question>();
  questions.forEach((q) => questionMap.set(q.id, q));

  const resultQuestionIds = Object.keys(activeResult.userAnswers);
  const resultQuestions: Question[] = resultQuestionIds
    .map((qid) => questionMap.get(qid))
    .filter((q): q is Question => q !== undefined);

  // Filter solutions
  const filteredSolutionQuestions = resultQuestions.filter((q) => {
    const userChoice = activeResult.userAnswers[q.id];
    const isUnattempted = userChoice === null || userChoice === undefined;
    const isCorrect = userChoice === q.correctOptionIndex;

    if (solutionFilter === 'correct') return isCorrect;
    if (solutionFilter === 'incorrect') return !isCorrect && !isUnattempted;
    if (solutionFilter === 'unattempted') return isUnattempted;
    return true;
  });

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}m ${s}s`;
  };

  const optionLetters = ['A', 'B', 'C', 'D', 'E'];

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16">
      {/* Top Banner Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={closeTestResult}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 px-3 py-1.5 bg-white border border-slate-200 rounded-lg shadow-xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Mock Tests</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setLang(lang === 'hi' ? 'en' : 'hi')}
            className="flex items-center gap-1 text-xs font-semibold text-blue-900 bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-lg"
          >
            <Languages className="w-3.5 h-3.5 text-blue-700" />
            <span>{lang === 'hi' ? 'English' : 'हिंदी'}</span>
          </button>

          <button
            onClick={() => startMockTest(activeResult.testId)}
            className="flex items-center gap-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 px-4 py-1.5 rounded-lg shadow-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Retake Test</span>
          </button>
        </div>
      </div>

      {/* Main Scorecard Hero Card */}
      <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-blue-900/50">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-6 border-b border-blue-800/50">
          <div>
            <span className="text-xs font-bold text-blue-300 uppercase tracking-wider block mb-1">
              Performance Scorecard
            </span>
            <h1 className="text-lg sm:text-2xl font-extrabold text-white">
              {activeResult.testTitle}
            </h1>
            <p className="text-xs text-blue-200 mt-1">
              Attempted on {activeResult.date} · Time Taken: {formatSeconds(activeResult.timeTakenSeconds)}
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 text-center border border-white/10 shrink-0">
            <span className="text-[11px] font-bold text-blue-200 uppercase tracking-wider block">
              FINAL SCORE
            </span>
            <div className="text-2xl sm:text-3xl font-extrabold text-white tabular-nums">
              {activeResult.score} <span className="text-sm font-normal text-blue-300">/ {activeResult.totalMarks}</span>
            </div>
          </div>
        </div>

        {/* 4 Performance Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6">
          <div className="p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="flex items-center gap-2 text-blue-300 text-xs font-medium mb-1">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>Est. Rank</span>
            </div>
            <div className="text-lg sm:text-xl font-bold tabular-nums">
              #{activeResult.rank}{' '}
              <span className="text-[11px] font-normal text-blue-300">/ {activeResult.totalParticipants.toLocaleString('en-IN')}</span>
            </div>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="flex items-center gap-2 text-blue-300 text-xs font-medium mb-1">
              <Award className="w-4 h-4 text-emerald-400" />
              <span>Percentile</span>
            </div>
            <div className="text-lg sm:text-xl font-bold tabular-nums text-emerald-300">
              {activeResult.percentile}%
            </div>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="flex items-center gap-2 text-blue-300 text-xs font-medium mb-1">
              <Target className="w-4 h-4 text-blue-400" />
              <span>Accuracy</span>
            </div>
            <div className="text-lg sm:text-xl font-bold tabular-nums">
              {activeResult.accuracyPercentage}%
            </div>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="flex items-center gap-2 text-blue-300 text-xs font-medium mb-1">
              <Clock className="w-4 h-4 text-purple-400" />
              <span>Avg Speed</span>
            </div>
            <div className="text-lg sm:text-xl font-bold tabular-nums">
              {Math.round(activeResult.timeTakenSeconds / (activeResult.totalQuestions || 1))}s / Q
            </div>
          </div>
        </div>
      </div>

      {/* Tabs: Analytics vs Solutions */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveTab('analytics')}
          className={`py-3 px-6 text-xs font-bold border-b-2 transition-colors ${
            activeTab === 'analytics'
              ? 'border-blue-600 text-blue-700 bg-white'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Overall Analytics
        </button>
        <button
          onClick={() => setActiveTab('solutions')}
          className={`py-3 px-6 text-xs font-bold border-b-2 transition-colors ${
            activeTab === 'solutions'
              ? 'border-blue-600 text-blue-700 bg-white'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Detailed Solutions ({resultQuestions.length})
        </button>
      </div>

      {/* Tab Content: Analytics */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          {/* Question Breakdown Strip */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-4">
              Question Attempt Breakdown
            </h3>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100">
                <span className="block text-2xl font-bold text-emerald-700 tabular-nums">
                  {activeResult.correctCount}
                </span>
                <span className="text-xs font-semibold text-emerald-800">Correct Answers</span>
              </div>
              <div className="p-4 bg-rose-50 rounded-xl border border-rose-100">
                <span className="block text-2xl font-bold text-rose-700 tabular-nums">
                  {activeResult.incorrectCount}
                </span>
                <span className="text-xs font-semibold text-rose-800">Incorrect Answers</span>
              </div>
              <div className="p-4 bg-slate-100 rounded-xl border border-slate-200">
                <span className="block text-2xl font-bold text-slate-700 tabular-nums">
                  {activeResult.unattemptedCount}
                </span>
                <span className="text-xs font-semibold text-slate-700">Skipped / Unattempted</span>
              </div>
            </div>
          </div>

          {/* Expert Teacher Rationale / Balvir Sir's Advice */}
          <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6 text-blue-950 space-y-2">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-blue-700" />
              <h4 className="text-sm font-bold">Balvir Sir's Analysis & Exam Advice:</h4>
            </div>
            <p className="text-xs text-blue-900 leading-relaxed">
              {activeResult.accuracyPercentage >= 75 ? (
                <>
                  Outstanding performance! Your accuracy of <strong>{activeResult.accuracyPercentage}%</strong> demonstrates a firm grasp of core pedagogy and Bihar Special facts. Keep practicing 5-option discriminators to maintain speed without negative marks.
                </>
              ) : (
                <>
                  Good effort! In BPSC exams, students often get confused by Option E ("उपर्युक्त में से एक से अधिक/कोई नहीं"). Review the detailed solutions below to reinforce memory points and save tricky questions to your Bookmarks tab.
                </>
              )}
            </p>
            <div className="pt-2">
              <button
                onClick={() => setActiveTab('solutions')}
                className="text-xs font-bold text-blue-700 hover:text-blue-800 underline"
              >
                Inspect All Question Explanations →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab Content: Detailed Solutions */}
      {activeTab === 'solutions' && (
        <div className="space-y-4">
          {/* Solution Filters */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg text-xs font-medium w-fit">
            <button
              onClick={() => setSolutionFilter('all')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                solutionFilter === 'all'
                  ? 'bg-white text-slate-900 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({resultQuestions.length})
            </button>
            <button
              onClick={() => setSolutionFilter('correct')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                solutionFilter === 'correct'
                  ? 'bg-white text-emerald-700 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Correct ({activeResult.correctCount})
            </button>
            <button
              onClick={() => setSolutionFilter('incorrect')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                solutionFilter === 'incorrect'
                  ? 'bg-white text-rose-700 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Incorrect ({activeResult.incorrectCount})
            </button>
            <button
              onClick={() => setSolutionFilter('unattempted')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                solutionFilter === 'unattempted'
                  ? 'bg-white text-slate-700 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Skipped ({activeResult.unattemptedCount})
            </button>
          </div>

          {/* Questions List */}
          <div className="space-y-4">
            {filteredSolutionQuestions.map((q, idx) => {
              const userChoice = activeResult.userAnswers[q.id];
              const isCorrect = userChoice === q.correctOptionIndex;
              const isUnattempted = userChoice === null || userChoice === undefined;
              const isBookmarked = currentUser?.bookmarks.includes(q.id);

              return (
                <div
                  key={q.id}
                  className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4"
                >
                  {/* Question header */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                        Q{idx + 1}
                      </span>
                      <span className="text-xs font-medium text-slate-500">{q.subject}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      {isCorrect && (
                        <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Correct</span>
                        </span>
                      )}
                      {!isCorrect && !isUnattempted && (
                        <span className="flex items-center gap-1 text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded">
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Incorrect</span>
                        </span>
                      )}
                      {isUnattempted && (
                        <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                          Skipped
                        </span>
                      )}

                      <button
                        onClick={() => toggleBookmark(q.id)}
                        className={`p-1.5 rounded-lg border transition-colors ${
                          isBookmarked
                            ? 'bg-amber-50 text-amber-600 border-amber-300'
                            : 'bg-white text-slate-400 border-slate-200 hover:text-slate-700'
                        }`}
                        title="Bookmark question"
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-500' : ''}`} />
                      </button>
                    </div>
                  </div>

                  {/* Question text */}
                  <div>
                    <p className="text-sm font-semibold text-slate-900 leading-relaxed">
                      {lang === 'hi' ? q.questionHi : q.questionEn}
                    </p>
                    <p className="text-xs text-slate-500 italic mt-0.5">
                      {lang === 'hi' ? q.questionEn : q.questionHi}
                    </p>
                  </div>

                  {/* 5 Options list */}
                  <div className="space-y-2">
                    {(lang === 'hi' ? q.optionsHi : q.optionsEn).map((optText, optIdx) => {
                      const letter = optionLetters[optIdx];
                      const isOptionCorrect = optIdx === q.correctOptionIndex;
                      const isOptionChosen = userChoice === optIdx;

                      let style = 'bg-slate-50/70 border-slate-200 text-slate-700';
                      if (isOptionCorrect) {
                        style = 'bg-emerald-50 border-emerald-400 text-emerald-950 font-medium ring-1 ring-emerald-400';
                      } else if (isOptionChosen && !isOptionCorrect) {
                        style = 'bg-rose-50 border-rose-300 text-rose-950';
                      }

                      return (
                        <div
                          key={optIdx}
                          className={`p-3 rounded-xl border text-xs flex items-center justify-between ${style}`}
                        >
                          <div className="flex items-center gap-2.5">
                            <span className="font-bold text-slate-800">({letter})</span>
                            <span>{optText}</span>
                          </div>
                          <div className="text-[11px] font-semibold shrink-0">
                            {isOptionCorrect && (
                              <span className="text-emerald-700 flex items-center gap-1">
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                                Correct Answer
                              </span>
                            )}
                            {isOptionChosen && !isOptionCorrect && (
                              <span className="text-rose-600">Your Choice</span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Detailed Explanation */}
                  <div className="p-4 bg-blue-50/60 rounded-xl border border-blue-200 space-y-1.5 text-xs text-slate-800">
                    <span className="font-bold text-slate-900 block">
                      {lang === 'hi' ? 'विस्तृत व्याख्या (Explanation):' : 'Detailed Explanation:'}
                    </span>
                    <p className="leading-relaxed">
                      {lang === 'hi' ? q.explanationHi : q.explanationEn}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
