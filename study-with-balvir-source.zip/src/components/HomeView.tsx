import React from 'react';
import {
  Sparkles,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Award,
  Users,
  Layers,
  HelpCircle,
  TrendingUp,
  FileText,
  Lock,
  ChevronRight,
  Download
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EXAM_CATEGORIES, PASS_PLANS } from '../data/mockData';
import { ExamCategory } from '../types';

export const HomeView: React.FC = () => {
  const {
    targetExam,
    setTargetExam,
    setCurrentView,
    mockTests,
    studyNotes,
    questions,
    appLanguage,
    startMockTest,
    currentUser,
    setIsArchitectureModalOpen,
    setIsExportModalOpen
  } = useApp();

  const selectedCategory = EXAM_CATEGORIES.find((c) => c.id === targetExam) || EXAM_CATEGORIES[0];
  const featuredMock = mockTests.find((t) => t.examCategory === targetExam) || mockTests[0];
  const categoryNotes = studyNotes.filter((n) => n.examCategory === targetExam);
  const examQuestions = questions.filter((q) => q.examCategory === targetExam);

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Banner Section */}
      <section className="bg-gradient-to-br from-blue-950 via-blue-900 to-indigo-950 text-white rounded-3xl overflow-hidden shadow-xl border border-blue-800/40">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-center">
          <div className="lg:col-span-7 p-6 sm:p-10 space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-200 border border-blue-400/30 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Target 2026: Bihar & National Teaching Exams</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight text-balance">
              {appLanguage === 'hi' ? (
                <>
                  BPSC TRE 3.0/4.0, CTET एवं JTET में <span className="text-blue-300">निश्चित सफलता</span> की सम्पूर्ण तैयारी
                </>
              ) : (
                <>
                  Crack BPSC TRE 3.0/4.0, CTET & JTET with <span className="text-blue-300">Authentic 5-Option</span> Exam Prep
                </>
              )}
            </h1>

            <p className="text-sm sm:text-base text-blue-100 max-w-xl leading-relaxed">
              {appLanguage === 'hi'
                ? 'आधिकारिक BPSC 5-विकल्प पैटर्न (विकल्प E: उपर्युक्त में से एक से अधिक/कोई नहीं) पर आधारित मॉक टेस्ट, विस्तृत द्विभाषी व्याख्या एवं निःशुल्क संपूर्ण अध्ययन सामग्री।'
                : 'Master the challenging BPSC 5-option examination format with bilingual explanations, real-time TCS iON rank simulations, and curriculum notes crafted by Balvir Sir.'}
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => startMockTest(featuredMock.id)}
                className="px-5 py-3 text-xs sm:text-sm font-bold text-blue-950 bg-white hover:bg-blue-50 rounded-xl transition-all shadow-md flex items-center gap-2"
              >
                <span>{appLanguage === 'hi' ? 'मुफ्त मॉक टेस्ट शुरू करें' : 'Start Free Mock Test'}</span>
                <ArrowRight className="w-4 h-4 text-blue-900" />
              </button>

              <button
                onClick={() => setCurrentView('practice')}
                className="px-5 py-3 text-xs sm:text-sm font-semibold text-white bg-blue-800/80 hover:bg-blue-800 rounded-xl transition-all border border-blue-400/30 flex items-center gap-2"
              >
                <HelpCircle className="w-4 h-4 text-blue-300" />
                <span>{appLanguage === 'hi' ? '5-विकल्प प्रश्न अभ्यास' : 'Practice 5-Option MCQs'}</span>
              </button>
            </div>

            {/* Micro stats banner */}
            <div className="pt-4 border-t border-blue-800/60 grid grid-cols-3 gap-3 text-xs text-blue-200">
              <div>
                <span className="block font-bold text-white text-base sm:text-lg tabular-nums">1,200+</span>
                <span className="text-[11px] text-blue-300">TRE Selections</span>
              </div>
              <div>
                <span className="block font-bold text-white text-base sm:text-lg tabular-nums">5-Option</span>
                <span className="text-[11px] text-blue-300">BPSC Pattern</span>
              </div>
              <div>
                <span className="block font-bold text-white text-base sm:text-lg tabular-nums">100% Free</span>
                <span className="text-[11px] text-blue-300">Foundation Notes</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 p-6 lg:p-8 flex justify-center">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-2 border-white/20 max-w-md w-full">
              <img
                src="/src/assets/images/study_balvir_banner_1792807513420.jpg"
                alt="Study with Balvir Classroom & Mock Test Preparation"
                className="w-full h-64 sm:h-72 object-cover object-center"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-950/90 via-transparent to-transparent flex items-end p-4">
                <div className="text-white text-xs">
                  <p className="font-bold text-sm">Target BPSC TRE 4.0 & 70th CCE</p>
                  <p className="text-blue-200 text-[11px]">Bilingual Content · Full Explanation Notes</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mobile Project Export / Source Download Banner */}
      <div className="p-4 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-600 text-white rounded-xl shrink-0">
            <Download className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-emerald-950">
              Download Complete Source Code ZIP (1.2 MB)
            </h3>
            <p className="text-[11px] text-emerald-800">
              Export all React components, 5-option questions, mock tests, and config files to your phone or computer.
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsExportModalOpen(true)}
          className="w-full sm:w-auto min-h-[40px] px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors shrink-0 flex items-center justify-center gap-1.5"
        >
          <span>Open Export & Download Hub</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Target Exam Selection Cards */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              {appLanguage === 'hi' ? 'परीक्षा श्रेणी चुनें' : 'Choose Your Examination'}
            </h2>
            <p className="text-xs text-slate-500">
              Select an exam category to focus your questions, mocks, and notes
            </p>
          </div>
          <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md">
            Active: {selectedCategory.badge}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {EXAM_CATEGORIES.map((cat) => {
            const isSelected = targetExam === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setTargetExam(cat.id)}
                className={`p-4 rounded-2xl text-left border transition-all ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/70 shadow-sm ring-1 ring-blue-600'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700">
                    {cat.badge}
                  </span>
                  {isSelected && (
                    <CheckCircle2 className="w-4 h-4 text-blue-700 fill-blue-100" />
                  )}
                </div>
                <h3 className="text-sm font-bold text-slate-900 mb-1 leading-snug">
                  {appLanguage === 'hi' ? cat.hindiName : cat.name}
                </h3>
                <p className="text-xs text-slate-500 line-clamp-2 mb-3">
                  {appLanguage === 'hi' ? cat.hindiDescription : cat.description}
                </p>
                <div className="text-[11px] text-slate-600 flex items-center justify-between pt-2 border-t border-slate-200/60">
                  <span>{cat.testCount} Tests</span>
                  <span>{cat.totalQuestions}+ Questions</span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* 5-Option Special Feature Callout */}
      <section className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          <div className="md:col-span-8 space-y-2">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
              BPSC Specialized Exam Engine
            </span>
            <h3 className="text-lg sm:text-xl font-bold">
              Why the 5th Option ("उपर्युक्त में से एक से अधिक / कोई नहीं") Decides Your Selection
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              In BPSC TRE and BPSC Civil Services, Option E famously bundles <em>"More than one of the above"</em> and <em>"None of the above"</em>. Nearly 20–25% of BPSC questions test this tricky discriminator. Our question bank specifically drills this pattern so you don't fall into the negative marking trap.
            </p>
          </div>
          <div className="md:col-span-4 flex flex-col gap-2">
            <button
              onClick={() => setCurrentView('practice')}
              className="w-full py-3 px-4 text-xs font-bold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors shadow-xs flex items-center justify-center gap-1.5"
            >
              <span>Practice 5-Option Questions</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <div className="text-[11px] text-slate-400 text-center">
              Available in both Hindi & English with detailed rationale
            </div>
          </div>
        </div>
      </section>

      {/* Featured Mock Test Card */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              {appLanguage === 'hi' ? 'विशेष मॉक टेस्ट' : 'Featured Mock Test'}
            </h2>
            <p className="text-xs text-slate-500">
              Simulated exam interface with countdown timer, negative marking & full scorecard
            </p>
          </div>
          <button
            onClick={() => setCurrentView('mock_tests')}
            className="text-xs font-semibold text-blue-700 hover:text-blue-800 flex items-center gap-1"
          >
            <span>View All ({mockTests.length})</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs hover:border-slate-300 transition-all">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-2 text-xs">
                <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                  {featuredMock.isPremium ? 'PREMIUM PASS' : 'FREE TEST'}
                </span>
                <span className="text-slate-500 font-medium">{selectedCategory.name}</span>
                <span className="text-slate-300">·</span>
                <span className="text-slate-500">{featuredMock.difficulty}</span>
              </div>
              <h3 className="text-base font-bold text-slate-900">
                {appLanguage === 'hi' ? featuredMock.hindiTitle : featuredMock.title}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {appLanguage === 'hi' ? featuredMock.descriptionHi : featuredMock.descriptionEn}
              </p>
              <div className="flex flex-wrap items-center gap-4 pt-1 text-xs text-slate-500 font-medium">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>{featuredMock.durationMinutes} Minutes</span>
                </span>
                <span className="flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-slate-400" />
                  <span>{featuredMock.totalMarks} Marks</span>
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  <span className="tabular-nums">{featuredMock.attemptsCount.toLocaleString('en-IN')} Attempted</span>
                </span>
              </div>
            </div>

            <div className="shrink-0 w-full sm:w-auto">
              <button
                onClick={() => startMockTest(featuredMock.id)}
                className="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2"
              >
                <span>{appLanguage === 'hi' ? 'टेस्ट शुरू करें' : 'Start Test Now'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Free Bilingual Notes Showcase */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              {appLanguage === 'hi' ? 'निःशुल्क अध्ययन नोट्स' : 'Free Bilingual Study Notes'}
            </h2>
            <p className="text-xs text-slate-500">
              Concise summaries, NCERT mapping, and memory points in Hindi & English
            </p>
          </div>
          <button
            onClick={() => setCurrentView('notes')}
            className="text-xs font-semibold text-blue-700 hover:text-blue-800 flex items-center gap-1"
          >
            <span>Read All Notes</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {categoryNotes.slice(0, 2).map((note) => (
            <div
              key={note.id}
              onClick={() => setCurrentView('notes')}
              className="p-5 bg-white border border-slate-200 rounded-2xl hover:border-blue-300 hover:shadow-xs transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                <span className="font-semibold text-blue-700">{note.subject}</span>
                <span className="text-[11px] text-slate-400">{note.readTimeMinutes} min read</span>
              </div>
              <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-700 transition-colors mb-2 line-clamp-2">
                {appLanguage === 'hi' ? note.titleHi : note.titleEn}
              </h3>
              <p className="text-xs text-slate-600 line-clamp-2 mb-3">
                {appLanguage === 'hi' ? note.contentHi.slice(0, 140) + '...' : note.contentEn.slice(0, 140) + '...'}
              </p>
              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                <span>By {note.author}</span>
                <span className="font-semibold text-blue-600 flex items-center gap-1">
                  Read Chapter <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing / Pass Preview in INR */}
      <section className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-6 sm:p-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl text-center md:text-left">
            <span className="text-xs font-bold text-blue-700 uppercase tracking-wider">
              Affordable Indian Rupees Pricing
            </span>
            <h3 className="text-lg sm:text-xl font-bold text-slate-900">
              Unlock All BPSC TRE 3.0 & 4.0 Tests at Just ₹199
            </h3>
            <p className="text-xs sm:text-sm text-slate-600">
              Get unlimited access to 45+ official pattern 5-option mock tests, detailed rank analytics, and exam-level question papers.
            </p>
          </div>
          <div className="flex flex-col items-center gap-2 shrink-0">
            <button
              onClick={() => setCurrentView('pricing')}
              className="px-6 py-3 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2"
            >
              <span>View All Pass Plans</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <span className="text-[11px] text-slate-500">100% Student-Friendly · Prototype Checkout</span>
          </div>
        </div>
      </section>
    </div>
  );
};
