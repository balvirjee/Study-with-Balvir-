import React, { useState } from 'react';
import {
  Clock,
  Award,
  Users,
  CheckCircle2,
  Lock,
  ArrowRight,
  Filter,
  AlertCircle,
  FileCheck,
  Info,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EXAM_CATEGORIES } from '../data/mockData';
import { ExamCategory, MockTest } from '../types';

export const MockTestsView: React.FC = () => {
  const {
    mockTests,
    targetExam,
    setTargetExam,
    currentUser,
    startMockTest,
    setCurrentView,
    appLanguage
  } = useApp();

  const [accessFilter, setAccessFilter] = useState<'all' | 'free' | 'premium'>('all');
  const [selectedTestForInstructions, setSelectedTestForInstructions] = useState<MockTest | null>(null);
  const [agreedToTerms, setAgreedToTerms] = useState<boolean>(false);
  const [preferredExamLang, setPreferredExamLang] = useState<'hi' | 'en'>(appLanguage);

  const activeCategory = EXAM_CATEGORIES.find((c) => c.id === targetExam) || EXAM_CATEGORIES[0];

  const filteredTests = mockTests.filter((test) => {
    if (test.examCategory !== targetExam) return false;
    if (accessFilter === 'free' && test.isPremium) return false;
    if (accessFilter === 'premium' && !test.isPremium) return false;
    return true;
  });

  const handleTestClick = (test: MockTest) => {
    if (test.isPremium && (!currentUser || !currentUser.hasPremiumPass)) {
      setCurrentView('pricing');
      return;
    }
    setSelectedTestForInstructions(test);
    setAgreedToTerms(false);
  };

  const handleStartExam = () => {
    if (!selectedTestForInstructions) return;
    const testId = selectedTestForInstructions.id;
    setSelectedTestForInstructions(null);
    startMockTest(testId);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold text-slate-900">
                Mock Test Series & All-India Rankings
              </h1>
              <span className="text-[11px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                {activeCategory.badge}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Real-time countdown timer, Section-wise question palette & negative marking simulations
            </p>
          </div>

          {/* Access filter pills */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
            <button
              onClick={() => setAccessFilter('all')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                accessFilter === 'all'
                  ? 'bg-white text-blue-700 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Tests ({mockTests.filter((t) => t.examCategory === targetExam).length})
            </button>
            <button
              onClick={() => setAccessFilter('free')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                accessFilter === 'free'
                  ? 'bg-white text-emerald-700 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Free Mocks
            </button>
            <button
              onClick={() => setAccessFilter('premium')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                accessFilter === 'premium'
                  ? 'bg-white text-amber-700 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Premium Pass
            </button>
          </div>
        </div>

        {/* Category tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs border-t border-slate-100 pt-3">
          {EXAM_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setTargetExam(cat.id)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors ${
                targetExam === cat.id
                  ? 'bg-blue-700 text-white shadow-xs font-semibold'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              {appLanguage === 'hi' ? cat.hindiName : cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Tests Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTests.map((test) => {
          const isLocked = test.isPremium && (!currentUser || !currentUser.hasPremiumPass);

          return (
            <div
              key={test.id}
              className={`bg-white border rounded-2xl p-5 transition-all flex flex-col justify-between ${
                test.isPremium ? 'border-amber-200/80 bg-gradient-to-b from-amber-50/20 to-white' : 'border-slate-200'
              } hover:border-blue-300 hover:shadow-xs`}
            >
              <div className="space-y-3">
                {/* Badges row */}
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    {test.isPremium ? (
                      <span className="flex items-center gap-1 font-bold text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded text-[11px]">
                        <Lock className="w-3 h-3 text-amber-600" />
                        <span>PREMIUM PASS (₹{test.priceInr || 199})</span>
                      </span>
                    ) : (
                      <span className="font-bold text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded text-[11px]">
                        FREE TEST
                      </span>
                    )}
                    <span className="text-slate-500 font-medium">{test.difficulty}</span>
                  </div>

                  <span className="text-[11px] text-slate-500 font-medium tabular-nums flex items-center gap-1">
                    <Users className="w-3 h-3 text-slate-400" />
                    <span>{test.attemptsCount.toLocaleString('en-IN')} Attempted</span>
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                  {appLanguage === 'hi' ? test.hindiTitle : test.title}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                  {appLanguage === 'hi' ? test.descriptionHi : test.descriptionEn}
                </p>

                {/* Specs row */}
                <div className="grid grid-cols-3 gap-2 py-2.5 px-3 bg-slate-50 rounded-xl text-xs text-slate-600 border border-slate-100">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="tabular-nums">{test.durationMinutes} Mins</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="tabular-nums">{test.totalMarks} Marks</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <FileCheck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="tabular-nums">{test.questionIds.length} MCQs</span>
                  </div>
                </div>

                {/* Negative marking info */}
                <div className="text-[11px] text-slate-500 flex items-center justify-between">
                  <span>
                    Negative Marking:{' '}
                    <strong className="text-slate-700">
                      {test.negativeMarking > 0 ? `-${test.negativeMarking} per wrong` : 'No Negative Marking'}
                    </strong>
                  </span>
                  <span>Pass Marks: {test.passMarks}</span>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-4 mt-3 border-t border-slate-100">
                {isLocked ? (
                  <button
                    onClick={() => handleTestClick(test)}
                    className="w-full py-2.5 px-4 text-xs font-bold text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors shadow-xs flex items-center justify-center gap-1.5"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Unlock with Pass (₹{test.priceInr || 199})</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleTestClick(test)}
                    className="w-full py-2.5 px-4 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs flex items-center justify-center gap-1.5"
                  >
                    <span>Start Test</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Pre-Test Instructions Modal */}
      {selectedTestForInstructions && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 bg-blue-900 text-white">
              <div>
                <span className="text-[11px] text-blue-200 font-semibold uppercase tracking-wider">
                  Examination Hall Instructions
                </span>
                <h2 className="text-base font-bold">
                  {selectedTestForInstructions.title}
                </h2>
              </div>
              <button
                onClick={() => setSelectedTestForInstructions(null)}
                className="p-1.5 text-blue-200 hover:text-white rounded-lg hover:bg-blue-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-5 overflow-y-auto">
              {/* Summary table */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700">
                <div>
                  <span className="text-slate-400 block text-[10px]">TOTAL TIME</span>
                  <span className="font-bold tabular-nums">{selectedTestForInstructions.durationMinutes} Minutes</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">QUESTIONS</span>
                  <span className="font-bold tabular-nums">{selectedTestForInstructions.questionIds.length} MCQs (5-Options)</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">TOTAL MARKS</span>
                  <span className="font-bold tabular-nums">{selectedTestForInstructions.totalMarks} Marks</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">NEGATIVE MARKING</span>
                  <span className="font-bold">
                    {selectedTestForInstructions.negativeMarking > 0
                      ? `-${selectedTestForInstructions.negativeMarking}`
                      : 'None'}
                  </span>
                </div>
              </div>

              {/* Instructions List */}
              <div className="space-y-2 text-xs text-slate-600 leading-relaxed">
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                  Important Guidelines:
                </h4>
                <ul className="list-disc pl-4 space-y-1.5">
                  <li>
                    The test uses the official <strong>5-option structure (A, B, C, D, E)</strong>. Pay careful attention to Option E ("More than one / None of the above").
                  </li>
                  <li>
                    The clock will be set at the server. The countdown timer at the top displays the time remaining to complete the examination.
                  </li>
                  <li>
                    <strong>Question Palette Legend:</strong>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2 pt-2 border-t border-slate-200 text-[11px]">
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 rounded bg-emerald-600 text-white text-[10px] flex items-center justify-center font-bold">✓</span>
                        <span>Answered</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 rounded bg-rose-600 text-white text-[10px] flex items-center justify-center font-bold">✕</span>
                        <span>Not Answered</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 rounded bg-purple-600 text-white text-[10px] flex items-center justify-center font-bold">?</span>
                        <span>Marked for Review</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 rounded bg-slate-200 text-slate-600 text-[10px] flex items-center justify-center">1</span>
                        <span>Not Visited</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    You can click <em>"Clear Response"</em> to deselect an option or <em>"Save & Next"</em> to confirm your choice.
                  </li>
                </ul>
              </div>

              {/* Choose Default Language */}
              <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-blue-900 block">Default Test Language:</span>
                  <span className="text-[11px] text-blue-700">You can also switch language per question during the test.</span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setPreferredExamLang('hi')}
                    className={`px-3 py-1 rounded-md text-xs font-semibold ${
                      preferredExamLang === 'hi'
                        ? 'bg-blue-700 text-white'
                        : 'bg-white text-slate-700 border border-slate-200'
                    }`}
                  >
                    हिंदी
                  </button>
                  <button
                    onClick={() => setPreferredExamLang('en')}
                    className={`px-3 py-1 rounded-md text-xs font-semibold ${
                      preferredExamLang === 'en'
                        ? 'bg-blue-700 text-white'
                        : 'bg-white text-slate-700 border border-slate-200'
                    }`}
                  >
                    English
                  </button>
                </div>
              </div>

              {/* Agree checkbox */}
              <label className="flex items-start gap-2.5 cursor-pointer pt-2 border-t border-slate-100">
                <input
                  type="checkbox"
                  checked={agreedToTerms}
                  onChange={(e) => setAgreedToTerms(e.target.checked)}
                  className="mt-0.5 w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                />
                <span className="text-xs text-slate-700 font-medium">
                  I have read and understood all instructions. I declare that I will attempt this mock test fairly without switching tabs or referencing external material.
                </span>
              </label>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-t border-slate-200">
              <button
                onClick={() => setSelectedTestForInstructions(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                onClick={handleStartExam}
                disabled={!agreedToTerms}
                className={`px-6 py-2.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-2 ${
                  agreedToTerms
                    ? 'bg-blue-600 hover:bg-blue-700 text-white'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <span>I am ready to begin</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
