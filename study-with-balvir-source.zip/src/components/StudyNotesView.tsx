import React, { useState } from 'react';
import {
  BookOpen,
  Download,
  Languages,
  Bookmark,
  Clock,
  ArrowRight,
  Sparkles,
  HelpCircle,
  CheckCircle2,
  Share2,
  FileText,
  Search,
  Filter
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EXAM_CATEGORIES } from '../data/mockData';
import { StudyNote } from '../types';

export const StudyNotesView: React.FC = () => {
  const {
    studyNotes,
    targetExam,
    setTargetExam,
    appLanguage,
    setAppLanguage,
    currentUser,
    toggleSavedNote,
    setCurrentView,
    showToast
  } = useApp();

  const [selectedNote, setSelectedNote] = useState<StudyNote | null>(null);
  const [noteLang, setNoteLang] = useState<'hi' | 'en'>(appLanguage);
  const [fontSizeLevel, setFontSizeLevel] = useState<'sm' | 'base' | 'lg'>('base');
  const [searchQuery, setSearchQuery] = useState('');

  const activeCategory = EXAM_CATEGORIES.find((c) => c.id === targetExam) || EXAM_CATEGORIES[0];

  const filteredNotes = studyNotes.filter((note) => {
    if (note.examCategory !== targetExam) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = note.titleEn.toLowerCase().includes(q) || note.titleHi.includes(q);
      const matchSubject = note.subject.toLowerCase().includes(q);
      return matchTitle || matchSubject;
    }
    return true;
  });

  const handleDownloadPdf = (note: StudyNote) => {
    showToast(`Downloading offline PDF: "${noteLang === 'hi' ? note.titleHi : note.titleEn}" (2.4 MB)`, 'success');
  };

  const isNoteSaved = (noteId: string) => currentUser?.savedNotes.includes(noteId);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold text-slate-900">
                Bilingual Study Notes & Formula Sheets
              </h1>
              <span className="text-[11px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                100% Free Access
              </span>
            </div>
            <p className="text-xs text-slate-500">
              NCERT-aligned high-yield study material written in clean Hindi and English
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setNoteLang(noteLang === 'hi' ? 'en' : 'hi')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
            >
              <Languages className="w-3.5 h-3.5 text-blue-700" />
              <span>Notes Language: {noteLang === 'hi' ? 'हिंदी' : 'English'}</span>
            </button>
          </div>
        </div>

        {/* Exam Categories bar & Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {EXAM_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setTargetExam(cat.id)}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors ${
                  targetExam === cat.id
                    ? 'bg-blue-700 text-white font-semibold shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat.badge}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search chapters or topics..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* Notes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredNotes.map((note) => {
          const saved = isNoteSaved(note.id);

          return (
            <div
              key={note.id}
              className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs hover:border-blue-300 transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                    {note.subject}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[11px] flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {note.readTimeMinutes} min read
                    </span>
                    <button
                      onClick={() => toggleSavedNote(note.id)}
                      className={`p-1.5 rounded-lg border transition-colors ${
                        saved
                          ? 'bg-amber-50 text-amber-600 border-amber-300'
                          : 'bg-white text-slate-400 border-slate-200 hover:text-slate-700'
                      }`}
                      title={saved ? 'Remove saved note' : 'Save to my student library'}
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-amber-500' : ''}`} />
                    </button>
                  </div>
                </div>

                <h3 className="text-base font-bold text-slate-900 leading-snug">
                  {noteLang === 'hi' ? note.titleHi : note.titleEn}
                </h3>

                {/* Key Takeaways preview */}
                <div className="space-y-1.5 p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-700">
                  <span className="font-bold text-slate-900 block text-[11px] uppercase tracking-wider">
                    {noteLang === 'hi' ? 'मुख्य परीक्षा बिंदु (Key Points):' : 'Key Exam Takeaways:'}
                  </span>
                  <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-600 line-clamp-3">
                    {(noteLang === 'hi' ? note.keyPointsHi : note.keyPointsEn).map((pt, i) => (
                      <li key={i}>{pt}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => handleDownloadPdf(note)}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>PDF Download</span>
                </button>

                <button
                  onClick={() => setSelectedNote(note)}
                  className="px-4 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <span>Read Chapter</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Chapter Reader Modal */}
      {selectedNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-3xl max-h-[92vh] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden">
            {/* Header */}
            <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="space-y-1 pr-4">
                <div className="flex items-center gap-2 text-xs">
                  <span className="font-semibold text-blue-300">{selectedNote.subject}</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-400">By {selectedNote.author}</span>
                </div>
                <h2 className="text-sm sm:text-base font-bold line-clamp-1">
                  {noteLang === 'hi' ? selectedNote.titleHi : selectedNote.titleEn}
                </h2>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-2 shrink-0">
                {/* Font size toggle */}
                <div className="hidden sm:flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700 text-xs">
                  <button
                    onClick={() => setFontSizeLevel('sm')}
                    className={`px-2 py-1 rounded ${fontSizeLevel === 'sm' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
                  >
                    A-
                  </button>
                  <button
                    onClick={() => setFontSizeLevel('base')}
                    className={`px-2 py-1 rounded ${fontSizeLevel === 'base' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
                  >
                    A
                  </button>
                  <button
                    onClick={() => setFontSizeLevel('lg')}
                    className={`px-2 py-1 rounded ${fontSizeLevel === 'lg' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
                  >
                    A+
                  </button>
                </div>

                {/* Lang switch in reader */}
                <button
                  onClick={() => setNoteLang(noteLang === 'hi' ? 'en' : 'hi')}
                  className="px-2.5 py-1 text-xs font-semibold bg-blue-600 hover:bg-blue-700 rounded-lg text-white"
                >
                  {noteLang === 'hi' ? 'Eng' : 'हिंदी'}
                </button>

                <button
                  onClick={() => setSelectedNote(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Body */}
            <div className="p-6 overflow-y-auto space-y-6">
              {/* Highlight Box */}
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-amber-900 font-bold text-xs uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>
                    {noteLang === 'hi' ? 'महत्वपूर्ण परीक्षा सार (High-Yield Takeaways):' : 'Key High-Yield Exam Points:'}
                  </span>
                </div>
                <ul className="list-disc pl-5 space-y-1.5 text-xs text-amber-950 leading-relaxed">
                  {(noteLang === 'hi' ? selectedNote.keyPointsHi : selectedNote.keyPointsEn).map((pt, i) => (
                    <li key={i}>{pt}</li>
                  ))}
                </ul>
              </div>

              {/* Full Content */}
              <div
                className={`text-slate-800 leading-relaxed whitespace-pre-line ${
                  fontSizeLevel === 'sm' ? 'text-xs' : fontSizeLevel === 'lg' ? 'text-base' : 'text-sm'
                }`}
              >
                {noteLang === 'hi' ? selectedNote.contentHi : selectedNote.contentEn}
              </div>

              {/* Subtitle in the other language */}
              <div className="pt-4 border-t border-slate-200">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
                  {noteLang === 'hi' ? 'English Reference Version:' : 'हिंदी संदर्भ संस्करण:'}
                </span>
                <p className="text-xs text-slate-600 italic leading-relaxed whitespace-pre-line">
                  {noteLang === 'hi' ? selectedNote.contentEn : selectedNote.contentHi}
                </p>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
              <button
                onClick={() => handleDownloadPdf(selectedNote)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded-lg border border-slate-200 shadow-xs flex items-center gap-2"
              >
                <Download className="w-4 h-4 text-slate-500" />
                <span>Save Offline PDF</span>
              </button>

              <button
                onClick={() => {
                  setSelectedNote(null);
                  setCurrentView('practice');
                }}
                className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs flex items-center gap-2"
              >
                <HelpCircle className="w-4 h-4" />
                <span>Practice 5-Option Questions on this Topic</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
