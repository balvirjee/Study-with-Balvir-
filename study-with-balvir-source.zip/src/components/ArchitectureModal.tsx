import React from 'react';
import { Database, ShieldCheck, CreditCard, Server, ArrowRight, ExternalLink, X, CheckCircle2, Download } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ArchitectureModal: React.FC = () => {
  const { isArchitectureModalOpen, setIsArchitectureModalOpen } = useApp();

  if (!isArchitectureModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-white rounded-2xl shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 bg-slate-900 text-white rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-600/30 text-blue-300">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Production Integration Blueprint</h2>
              <p className="text-xs text-slate-300">
                Study with Balvir — Prototype vs. Full-Scale Backend Architecture
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsArchitectureModalOpen(false)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-sm">
            <span className="font-semibold">Notice for Evaluators & Developers: </span>
            This working prototype runs a responsive, client-persisted simulation of all Testbook/Adda247 workflows. Below is the exact production architecture mapping required for enterprise deployment with real money transactions, concurrent mock test loads, and secure authentication.
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Database Component */}
            <div className="p-5 border border-slate-200 rounded-xl bg-slate-50/50">
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">1. Database (Cloud SQL / Firestore)</h3>
                  <span className="text-[11px] font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                    Requires Cloud Database
                  </span>
                </div>
              </div>
              <p className="text-xs text-slate-600 mb-3 leading-relaxed">
                Relational PostgreSQL (via Cloud SQL) or Google Cloud Firestore for structured question banks, section timings, and ACID-compliant test submissions.
              </p>
              <div className="text-[11px] text-slate-500 font-mono space-y-1 bg-white p-2.5 rounded border border-slate-200">
                <div>• collections: <span className="text-slate-700 font-semibold">questions</span>, <span className="text-slate-700 font-semibold">mock_tests</span></div>
                <div>• collections: <span className="text-slate-700 font-semibold">users</span>, <span className="text-slate-700 font-semibold">test_attempts</span></div>
                <div>• collections: <span className="text-slate-700 font-semibold">notes</span>, <span className="text-slate-700 font-semibold">transactions</span></div>
              </div>
            </div>

            {/* Secure Auth Component */}
            <div className="p-5 border border-slate-200 rounded-xl bg-slate-50/50">
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">2. Secure Login & Phone OTP</h3>
                  <span className="text-[11px] font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                    Requires Identity Provider
                  </span>
                </div>
              </div>
              <p className="text-xs text-slate-600 mb-3 leading-relaxed">
                Indian EdTech apps standardly use Mobile OTP (via Msg91 / Twilio) alongside Google One-Tap OAuth. Tokens stored in secure HTTP-only cookies.
              </p>
              <div className="text-[11px] text-slate-500 font-mono space-y-1 bg-white p-2.5 rounded border border-slate-200">
                <div>• Firebase Auth / Supabase Auth (JWT)</div>
                <div>• SMS Gateway for +91 Mobile OTP</div>
                <div>• Role-based Access (Student / Content Admin)</div>
              </div>
            </div>

            {/* Payment Integration */}
            <div className="p-5 border border-slate-200 rounded-xl bg-slate-50/50">
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">3. Indian Payment Gateway (₹ INR)</h3>
                  <span className="text-[11px] font-medium text-rose-700 bg-rose-50 px-2 py-0.5 rounded">
                    Real Payments Disabled
                  </span>
                </div>
              </div>
              <p className="text-xs text-slate-600 mb-3 leading-relaxed">
                Razorpay or Cashfree standard checkout supporting UPI (GPay, PhonePe, Paytm), NetBanking, and RuPay cards. Server-side webhook HMAC-SHA256 signature verification.
              </p>
              <div className="text-[11px] text-slate-500 font-mono space-y-1 bg-white p-2.5 rounded border border-slate-200">
                <div>• POST /api/payments/create-order</div>
                <div>• Webhook: order.paid with signature check</div>
                <div>• Unlocks `hasPremiumPass` permanently</div>
              </div>
            </div>

            {/* Content Delivery & Anti-Cheating */}
            <div className="p-5 border border-slate-200 rounded-xl bg-slate-50/50">
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="p-2 bg-purple-100 text-purple-700 rounded-lg">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">4. CDN & Test Integrity Engine</h3>
                  <span className="text-[11px] font-medium text-purple-700 bg-purple-50 px-2 py-0.5 rounded">
                    Scalability & Security
                  </span>
                </div>
              </div>
              <p className="text-xs text-slate-600 mb-3 leading-relaxed">
                Cloudflare / Cloud Storage CDN for watermarked PDF study notes. Server-authoritative timer sync and tab-switch proctoring for mock tests.
              </p>
              <div className="text-[11px] text-slate-500 font-mono space-y-1 bg-white p-2.5 rounded border border-slate-200">
                <div>• Server-side countdown synchronization</div>
                <div>• Watermarked dynamic PDF compilation</div>
                <div>• Anti-screenshot & copy-protection policies</div>
              </div>
            </div>
          </div>

          {/* Current Prototype Status */}
          <div className="p-4 bg-slate-100 rounded-xl">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Current Prototype State (Fully Interactive):
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>5-Option BPSC MCQ practice with Hindi/English</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>TCS iON / Testbook style timed mock engine</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Scorecard, rank prediction & solution review</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Admin panel for managing questions & tests</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Simulated pass unlock with INR pricing</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Local storage persistence for student progress</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-t border-slate-200 rounded-b-2xl">
          <a
            href="/study-with-balvir-source.zip"
            download="study-with-balvir-source.zip"
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-emerald-600" />
            <span>Download Complete Project (ZIP)</span>
          </a>

          <button
            onClick={() => setIsArchitectureModalOpen(false)}
            className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Got it, Back to App
          </button>
        </div>
      </div>
    </div>
  );
};
