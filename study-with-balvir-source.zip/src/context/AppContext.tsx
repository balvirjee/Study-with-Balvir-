import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  ExamCategory,
  Question,
  MockTest,
  StudyNote,
  User,
  TestAttemptResult,
} from '../types';
import {
  INITIAL_QUESTIONS,
  INITIAL_MOCK_TESTS,
  INITIAL_STUDY_NOTES,
  DEMO_USER,
  DEMO_ADMIN
} from '../data/mockData';

export type AppView = 'home' | 'mock_tests' | 'practice' | 'notes' | 'dashboard' | 'pricing' | 'admin';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning';
}

interface AppContextType {
  // State
  currentUser: User | null;
  currentView: AppView;
  targetExam: ExamCategory;
  appLanguage: 'hi' | 'en';
  questions: Question[];
  mockTests: MockTest[];
  studyNotes: StudyNote[];
  activeTest: MockTest | null;
  activeResult: TestAttemptResult | null;
  isAuthModalOpen: boolean;
  isArchitectureModalOpen: boolean;
  isExportModalOpen: boolean;
  toasts: Toast[];

  // Actions
  setCurrentView: (view: AppView) => void;
  setTargetExam: (exam: ExamCategory) => void;
  setAppLanguage: (lang: 'hi' | 'en') => void;
  setIsAuthModalOpen: (open: boolean) => void;
  setIsArchitectureModalOpen: (open: boolean) => void;
  setIsExportModalOpen: (open: boolean) => void;
  loginAsDemoStudent: () => void;
  loginAsDemoAdmin: () => void;
  loginUser: (email: string, name?: string, role?: 'student' | 'admin') => void;
  logout: () => void;
  toggleBookmark: (questionId: string) => void;
  toggleSavedNote: (noteId: string) => void;
  startMockTest: (testId: string) => void;
  exitActiveTest: () => void;
  completeMockTest: (result: TestAttemptResult) => void;
  viewTestResult: (result: TestAttemptResult) => void;
  closeTestResult: () => void;
  unlockPremiumPass: (planName: string) => void;

  // Admin Actions
  addQuestion: (q: Omit<Question, 'id'>) => void;
  updateQuestion: (q: Question) => void;
  deleteQuestion: (id: string) => void;
  addMockTest: (test: Omit<MockTest, 'id' | 'attemptsCount'>) => void;
  toggleTestPremium: (id: string) => void;
  deleteMockTest: (id: string) => void;
  addStudyNote: (note: Omit<StudyNote, 'id'>) => void;
  deleteStudyNote: (id: string) => void;
  resetAllDataToDefault: () => void;
  showToast: (message: string, type?: 'success' | 'info' | 'warning') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // User state
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('swb_user');
    if (saved) {
      try { return JSON.parse(saved); } catch { /* ignore */ }
    }
    return DEMO_USER; // Default logged in as demo student
  });

  const [currentView, setCurrentView] = useState<AppView>('home');
  const [targetExam, setTargetExam] = useState<ExamCategory>('bpsc_tre');
  const [appLanguage, setAppLanguage] = useState<'hi' | 'en'>('hi'); // Default Hindi friendly for Hindi heartland exams

  // Questions, Tests, Notes
  const [questions, setQuestions] = useState<Question[]>(() => {
    const saved = localStorage.getItem('swb_questions');
    if (saved) {
      try { return JSON.parse(saved); } catch { /* ignore */ }
    }
    return INITIAL_QUESTIONS;
  });

  const [mockTests, setMockTests] = useState<MockTest[]>(() => {
    const saved = localStorage.getItem('swb_mock_tests');
    if (saved) {
      try { return JSON.parse(saved); } catch { /* ignore */ }
    }
    return INITIAL_MOCK_TESTS;
  });

  const [studyNotes, setStudyNotes] = useState<StudyNote[]>(() => {
    const saved = localStorage.getItem('swb_study_notes');
    if (saved) {
      try { return JSON.parse(saved); } catch { /* ignore */ }
    }
    return INITIAL_STUDY_NOTES;
  });

  const [activeTest, setActiveTest] = useState<MockTest | null>(null);
  const [activeResult, setActiveResult] = useState<TestAttemptResult | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isArchitectureModalOpen, setIsArchitectureModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Sync to local storage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('swb_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('swb_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('swb_questions', JSON.stringify(questions));
  }, [questions]);

  useEffect(() => {
    localStorage.setItem('swb_mock_tests', JSON.stringify(mockTests));
  }, [mockTests]);

  useEffect(() => {
    localStorage.setItem('swb_study_notes', JSON.stringify(studyNotes));
  }, [studyNotes]);

  const showToast = (message: string, type: 'success' | 'info' | 'warning' = 'info') => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 5);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  const loginAsDemoStudent = () => {
    setCurrentUser(DEMO_USER);
    setIsAuthModalOpen(false);
    showToast(`Logged in as Student: ${DEMO_USER.name}`, 'success');
  };

  const loginAsDemoAdmin = () => {
    setCurrentUser(DEMO_ADMIN);
    setIsAuthModalOpen(false);
    setCurrentView('admin');
    showToast(`Logged in as Admin: ${DEMO_ADMIN.name}`, 'success');
  };

  const loginUser = (email: string, name?: string, role: 'student' | 'admin' = 'student') => {
    const isAdminEmail = email.toLowerCase().trim() === 'balvirjee@gmail.com';
    const user: User = {
      id: 'usr_' + Date.now(),
      name: name || (isAdminEmail ? 'Balvir Singh' : email.split('@')[0]),
      email,
      phone: '+91 98765 00000',
      role: isAdminEmail ? 'admin' : role,
      targetExam,
      hasPremiumPass: isAdminEmail,
      bookmarks: [],
      savedNotes: [],
      testHistory: []
    };
    setCurrentUser(user);
    setIsAuthModalOpen(false);
    if (user.role === 'admin') {
      setCurrentView('admin');
    }
    showToast(`Welcome, ${user.name}! Signed in successfully.`, 'success');
  };

  const logout = () => {
    setCurrentUser(null);
    setCurrentView('home');
    showToast('Signed out successfully.', 'info');
  };

  const toggleBookmark = (questionId: string) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      showToast('Please login to bookmark questions', 'warning');
      return;
    }

    const isBookmarked = currentUser.bookmarks.includes(questionId);
    const updatedBookmarks = isBookmarked
      ? currentUser.bookmarks.filter((id) => id !== questionId)
      : [...currentUser.bookmarks, questionId];

    setCurrentUser({
      ...currentUser,
      bookmarks: updatedBookmarks
    });

    showToast(isBookmarked ? 'Question removed from bookmarks' : 'Question bookmarked for quick revision!', 'success');
  };

  const toggleSavedNote = (noteId: string) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      showToast('Please login to save study notes', 'warning');
      return;
    }

    const isSaved = currentUser.savedNotes.includes(noteId);
    const updatedNotes = isSaved
      ? currentUser.savedNotes.filter((id) => id !== noteId)
      : [...currentUser.savedNotes, noteId];

    setCurrentUser({
      ...currentUser,
      savedNotes: updatedNotes
    });

    showToast(isSaved ? 'Note removed from library' : 'Note saved to your student library!', 'success');
  };

  const startMockTest = (testId: string) => {
    const test = mockTests.find((t) => t.id === testId);
    if (!test) {
      showToast('Test not found', 'warning');
      return;
    }

    if (test.isPremium && (!currentUser || !currentUser.hasPremiumPass)) {
      setCurrentView('pricing');
      showToast('This is a Premium Test. Please unlock a Pass to continue.', 'warning');
      return;
    }

    setActiveTest(test);
    setActiveResult(null);
  };

  const exitActiveTest = () => {
    setActiveTest(null);
  };

  const completeMockTest = (result: TestAttemptResult) => {
    if (currentUser) {
      const updatedHistory = [result, ...(currentUser.testHistory || [])];
      setCurrentUser({
        ...currentUser,
        testHistory: updatedHistory
      });
    }

    // Increment attempts on test
    setMockTests((prev) =>
      prev.map((t) =>
        t.id === result.testId ? { ...t, attemptsCount: t.attemptsCount + 1 } : t
      )
    );

    setActiveTest(null);
    setActiveResult(result);
    showToast(`Test completed! You scored ${result.score}/${result.totalMarks} marks.`, 'success');
  };

  const viewTestResult = (result: TestAttemptResult) => {
    setActiveResult(result);
  };

  const closeTestResult = () => {
    setActiveResult(null);
  };

  const unlockPremiumPass = (planName: string) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      showToast('Please sign in or register to purchase a Pass', 'warning');
      return;
    }

    setCurrentUser({
      ...currentUser,
      hasPremiumPass: true,
      passPlanName: planName,
      passExpiryDate: '2027-10-23'
    });

    showToast(`Congratulations! ${planName} is now active on your account.`, 'success');
  };

  // Admin methods
  const addQuestion = (newQ: Omit<Question, 'id'>) => {
    const created: Question = {
      ...newQ,
      id: 'q_custom_' + Date.now()
    };
    setQuestions((prev) => [created, ...prev]);
    showToast('Question created and added to question bank!', 'success');
  };

  const updateQuestion = (updatedQ: Question) => {
    setQuestions((prev) => prev.map((q) => (q.id === updatedQ.id ? updatedQ : q)));
    showToast('Question updated successfully!', 'success');
  };

  const deleteQuestion = (id: string) => {
    setQuestions((prev) => prev.filter((q) => q.id !== id));
    showToast('Question deleted.', 'info');
  };

  const addMockTest = (newTest: Omit<MockTest, 'id' | 'attemptsCount'>) => {
    const created: MockTest = {
      ...newTest,
      id: 'test_custom_' + Date.now(),
      attemptsCount: 0
    };
    setMockTests((prev) => [created, ...prev]);
    showToast('New Mock Test published successfully!', 'success');
  };

  const toggleTestPremium = (id: string) => {
    setMockTests((prev) =>
      prev.map((t) => (t.id === id ? { ...t, isPremium: !t.isPremium } : t))
    );
    showToast('Mock test access status updated.', 'info');
  };

  const deleteMockTest = (id: string) => {
    setMockTests((prev) => prev.filter((t) => t.id !== id));
    showToast('Mock test deleted.', 'info');
  };

  const addStudyNote = (newNote: Omit<StudyNote, 'id'>) => {
    const created: StudyNote = {
      ...newNote,
      id: 'note_custom_' + Date.now()
    };
    setStudyNotes((prev) => [created, ...prev]);
    showToast('Study note published to student library!', 'success');
  };

  const deleteStudyNote = (id: string) => {
    setStudyNotes((prev) => prev.filter((n) => n.id !== id));
    showToast('Study note deleted.', 'info');
  };

  const resetAllDataToDefault = () => {
    localStorage.removeItem('swb_questions');
    localStorage.removeItem('swb_mock_tests');
    localStorage.removeItem('swb_study_notes');
    localStorage.removeItem('swb_user');
    setQuestions(INITIAL_QUESTIONS);
    setMockTests(INITIAL_MOCK_TESTS);
    setStudyNotes(INITIAL_STUDY_NOTES);
    setCurrentUser(DEMO_USER);
    showToast('Data reset to default curriculum state.', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        currentView,
        targetExam,
        appLanguage,
        questions,
        mockTests,
        studyNotes,
        activeTest,
        activeResult,
        isAuthModalOpen,
        isArchitectureModalOpen,
        isExportModalOpen,
        toasts,
        setCurrentView,
        setTargetExam,
        setAppLanguage,
        setIsAuthModalOpen,
        setIsArchitectureModalOpen,
        setIsExportModalOpen,
        loginAsDemoStudent,
        loginAsDemoAdmin,
        loginUser,
        logout,
        toggleBookmark,
        toggleSavedNote,
        startMockTest,
        exitActiveTest,
        completeMockTest,
        viewTestResult,
        closeTestResult,
        unlockPremiumPass,
        addQuestion,
        updateQuestion,
        deleteQuestion,
        addMockTest,
        toggleTestPremium,
        deleteMockTest,
        addStudyNote,
        deleteStudyNote,
        resetAllDataToDefault,
        showToast
      }}
    >
      {children}

      {/* Floating Notifications / Toasts */}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto px-4 py-3 rounded-lg shadow-lg text-sm font-medium border transition-all transform animate-in fade-in slide-in-from-top-2 ${
              toast.type === 'success'
                ? 'bg-emerald-900 text-emerald-100 border-emerald-700'
                : toast.type === 'warning'
                ? 'bg-amber-900 text-amber-100 border-amber-700'
                : 'bg-slate-900 text-white border-slate-700'
            }`}
          >
            {toast.message}
          </div>
        ))}
      </div>
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
