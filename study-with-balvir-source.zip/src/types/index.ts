export type ExamCategory = 'bpsc_tre' | 'ctet' | 'jtet' | 'bpsc_cce';

export interface ExamCategoryInfo {
  id: ExamCategory;
  name: string;
  hindiName: string;
  badge: string;
  description: string;
  hindiDescription: string;
  totalQuestions: number;
  testCount: number;
  subjects: string[];
}

export interface Question {
  id: string;
  examCategory: ExamCategory;
  subject: string;
  questionEn: string;
  questionHi: string;
  optionsEn: [string, string, string, string, string]; // 5 options
  optionsHi: [string, string, string, string, string]; // 5 options
  correctOptionIndex: number; // 0 = A, 1 = B, 2 = C, 3 = D, 4 = E
  explanationEn: string;
  explanationHi: string;
  difficulty: 'Easy' | 'Moderate' | 'Hard';
  yearTag?: string;
  isBPSC5thOptionStandard?: boolean; // Option E is standard "More than one / None of the above"
}

export interface MockTest {
  id: string;
  title: string;
  hindiTitle: string;
  examCategory: ExamCategory;
  isPremium: boolean;
  priceInr?: number;
  durationMinutes: number;
  totalMarks: number;
  passMarks: number;
  negativeMarking: number; // e.g. 0.25 or 0
  questionIds: string[];
  attemptsCount: number;
  difficulty: 'Easy' | 'Moderate' | 'Exam Level';
  descriptionEn: string;
  descriptionHi: string;
}

export interface StudyNote {
  id: string;
  examCategory: ExamCategory;
  subject: string;
  titleEn: string;
  titleHi: string;
  readTimeMinutes: number;
  contentEn: string;
  contentHi: string;
  keyPointsEn: string[];
  keyPointsHi: string[];
  isFree: boolean;
  publishedDate: string;
  author: string;
}

export interface TestAttemptResult {
  id: string;
  testId: string;
  testTitle: string;
  examCategory: ExamCategory;
  date: string;
  score: number;
  totalMarks: number;
  totalQuestions: number;
  correctCount: number;
  incorrectCount: number;
  unattemptedCount: number;
  timeTakenSeconds: number;
  accuracyPercentage: number;
  percentile: number;
  rank: number;
  totalParticipants: number;
  userAnswers: Record<string, number | null>; // questionId -> optionIndex (0-4) or null
  markedForReview: string[]; // questionIds
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'student' | 'admin';
  targetExam: ExamCategory;
  hasPremiumPass: boolean;
  passPlanName?: string;
  passExpiryDate?: string;
  bookmarks: string[]; // question IDs
  savedNotes: string[]; // note IDs
  testHistory: TestAttemptResult[];
}

export interface PassPlan {
  id: string;
  title: string;
  hindiTitle: string;
  priceInr: number;
  originalPriceInr: number;
  validity: string;
  targetExamBadge: string;
  popular?: boolean;
  features: string[];
  hindiFeatures: string[];
}
