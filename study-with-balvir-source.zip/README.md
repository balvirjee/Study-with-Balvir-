# Study with Balvir — BPSC TRE, CTET, JTET & BPSC Exam Prep

A complete, mobile-friendly educational examination preparation web application inspired by **Testbook** and **Adda247**, specialized for **BPSC TRE (3.0 & 4.0)**, **CTET (Paper 1 & 2)**, **JTET**, and **BPSC Civil Services (CCE)** aspirants.

---

## 🚀 Key Features

1. **5-Option MCQ Practice Arena**:
   - Built specifically for the BPSC standard **5-option format (A, B, C, D, E)**.
   - Dedicated drill on **Option E** (*"More than one of the above / None of the above"* / *"उपर्युक्त में से एक से अधिक / उपर्युक्त में से कोई नहीं"*).
   - Instant answer verification with animated feedback and rich bilingual explanations (विस्तृत व्याख्या).
   - Bookmark questions for quick revision.

2. **Timed Mock Test Examination Engine (TCS iON / Testbook Style)**:
   - Real-time countdown timer with tabular numerals and low-time visual alerts.
   - 5-state Question Palette (*Answered*, *Not Answered*, *Marked for Review*, *Answered & Marked*, *Not Visited*).
   - Action controls: *Clear Response*, *Save & Next*, and *Mark for Review & Next*.
   - Pre-submission review summary modal.

3. **In-Depth Scorecard & Performance Analytics**:
   - Final score, accuracy %, percentile calculation, estimated All-India Rank, and average speed per question.
   - Question-by-question review with filters (*Correct*, *Incorrect*, *Skipped*) and expert guidance.

4. **Free Bilingual Study Notes**:
   - NCERT-aligned chapters in both Hindi (हिंदी) and English.
   - Integrated reader with font size scaling (A-, A, A+), key takeaway bullet summaries, and offline PDF download simulation.

5. **Pass Series & Indian Rupee (₹) Pricing**:
   - Categorized *Free* and *Premium* mock tests.
   - Super Pass plans in INR (₹199, ₹299, ₹249) with coupon code support (`BALVIR10`, `TRE2026`).
   - Simulated checkout with a transparent notice explaining production Razorpay/Cashfree webhook integration.

6. **Student Dashboard & Revision Hub**:
   - Study streak tracker, average accuracy %, tests attempted counter, and bookmarked questions.
   - Complete test attempt history with one-click *View Analysis* and *Retake Test*.
   - Specialized *Practice Bookmarks Only* quiz mode.

7. **Educator & Content Administration Console**:
   - Manage the Question Bank: Add, edit, and delete 5-option MCQs in English and Hindi.
   - Manage Mock Tests: Publish tests, configure duration, total marks, and toggle Free/Premium status.
   - Manage Study Notes: Publish bilingual chapters.
   - One-click *Reset Demo Data* to restore default seed data.

---

## 🛠️ Tech Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, Lucide React icons, Motion
- **Typography**: Plus Jakarta Sans & Noto Sans Devanagari (optimized for bilingual Hindi/English reading)
- **State Management**: React Context with automatic `localStorage` synchronization
- **Design System**: Royal Navy & Crisp White palette conforming to strict anti-slop guidelines

---

## 📦 Local Installation & Setup

To run this application locally on your machine:

```bash
# 1. Unzip the downloaded file
unzip study-with-balvir-source.zip -d study-with-balvir
cd study-with-balvir

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev
```

Open your browser at `http://localhost:3000` (or the port indicated in your terminal).

To create a production build:
```bash
npm run build
```

---

## 🏛️ Production Integration Architecture

When deploying to a production enterprise environment:

1. **Database**: Replace `localStorage` with **PostgreSQL (Cloud SQL)** or **Firebase Firestore** for centralized question banking, multi-tenant student attempts, and real-time rank computation.
2. **Authentication**: Connect the auth modal to **Firebase Authentication** or **SMS Gateway (+91 mobile OTP via Msg91/Twilio)** with secure HTTP-only cookies.
3. **Payments**: Wire the checkout modal to **Razorpay / Cashfree Standard Checkout** with backend HMAC-SHA256 signature verification on order completion webhooks.
4. **Content Delivery**: Host study PDFs and video explanations on **Google Cloud Storage / Cloudflare CDN** with server-side watermarking.

---

## 📄 License & Credits

- Platform: **Study with Balvir**
- Director: **Balvir Singh** (`balvirjee@gmail.com`)
- Target Examinations: BPSC TRE 3.0/4.0, CTET Paper 1 & 2, JTET, and 70th/71st BPSC CCE.
